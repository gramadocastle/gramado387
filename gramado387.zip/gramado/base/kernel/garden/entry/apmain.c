// apmain.c
// Main file when the kernel starts up some AP processor.
// Created by Fred Nora

#include <kernel.h>


//static void __ap_ANIMATION_loop(void);
//static void __ap_ANIMATION_loop2(int lapic_id);
static void __ap_kmain_imp(void);


static void __ap_r0_idle_loop(void);

// ========================================

// #test: Dummy ring 0 thread for APs
static void __ap_r0_idle_loop(void)
{
    printk("AP: Dummy thread for AP core\n");

    // #test
    // #ps: 
    // The interruptiong was called from ring 0.
    // probably the context switch will point that it was called from ring 0 and crash.

    // asm ("int $3");

    while(1){
        asm ("cli");
        asm ("hlt");
    };
}


/*
static void __ap_ANIMATION_loop(void)
{
    int i=0;

//
// Animation
//

    // #test
    // Drawing rectangles
    unsigned int Color = COLOR_BLACK;
    int Counter = 0;

    while (1){

        //while (apic_SPINLOCK == TRUE){ asm ("pause \n"); };

        Counter++;
        Color = COLOR_YELLOW;
        if (Counter % 2 == 0)
            Color = COLOR_RED;

        for (i=0; i<100; i++){
            frontbuffer_draw_rectangle( 0, i, 4, 4, Color, 0 );
        };

        //wproxy_ap_test();

        // #test
        // Delay
        // With this delay we can have performance enough 
        // in both cores to make tests.
        // #todo: Do not change it for now.
        asm ("xorl %%eax, %%eax" ::);
        asm ("pause \n");
        asm ("outb %%al, $0x80"  ::);


        // Syscall
        // It needs only to be called from ring 3 actually
        // #test: The handler was called.
        // #bugbug:
        // We can't do that because the AP still do not a 
        // TSS or a ring 0 stack.

        //if (system_state == SYSTEM_RUNNING)
            //asm ("int $0x80 \n");

        // spurious
        // #bugbug
        // It's not working. The system crashes.
        // Probably still because the lack of tss and ring 0 stack.
        //if (system_state == SYSTEM_RUNNING)
            //asm ("int $0xFF \n");

        // #bugbug
        // Testing the handlers for taskswitching
        // if (system_state == SYSTEM_RUNNING)
            //asm ("int $32 \n");
    };
}
*/

/*
static void __ap_ANIMATION_loop2(int lapic_id)
{
    int i;
    unsigned int Color = COLOR_BLACK;
    int Counter = 0;

    // Safety
    if (lapic_id < 0 || lapic_id >= NR_CPUS)
        lapic_id = 0;

    // Each AP gets its own vertical band
    // AP 1 → top band, AP 2 → middle, AP 3 → lower, etc.
    int base_y = 20 + (lapic_id * 30);   // adjust spacing as you like
    int height = 20;

    while (1) {
        Counter++;

        // Different color per AP + animation
        switch (lapic_id) {
            case 1:  Color = (Counter & 1) ? COLOR_YELLOW : COLOR_RED;     break;
            case 2:  Color = (Counter & 1) ? COLOR_CYAN   : COLOR_BLUE;    break;
            case 3:  Color = (Counter & 1) ? COLOR_GREEN  : COLOR_CYAN;    break;
            default: Color = (Counter & 1) ? COLOR_WHITE  : COLOR_GRAY;    break;
        }

        // Draw a moving bar in this AP's band
        for (i = 0; i < 200; i++) {
            frontbuffer_draw_rectangle(
                i * 4,                  // x
                base_y,                 // y
                4,                      // width
                height,                 // height
                Color,
                0
            );
        }

        // Simple delay so we can actually see the animation
        int d;
        for (d=0; d < 50000; d++) 
        {
            asm volatile ("pause");
        }
    }
}
*/

//
// $
// AP INITIALIZATION
//

// #todo
// We need One GDT per-core AND 
// One IDT per-core (in x86-64 SMP)
// #ps: We have support for GDT in C.

static void __ap_kmain_imp(void)
{
    int i=0;
    int lapic_id = -1;

    asm ("cli");  // For safety

// CLTS — Clear Task-Switched Flag in CR0
// The processor sets the TS flag every time a task switch occurs. 
// For taskswitching via hardware i guess.
// see:
// https://www.felixcloutier.com/x86/clts

    asm volatile ("clts \n");

    //PROGRESS("AP_kmain: \n")

    // #test
    unsigned long *ap_shmm = (unsigned long *) ____DANGER_TRAMPOLINE_SHARED_AREA;
    lapic_id = (int) ap_shmm[1];
    printk("AP_kmain: lapic info ID %d\n", ap_shmm[1]);
    // #ps:
    // The lapic_info_id is the index for the lapic_info[] table.
    // It can't be zero because the first entry is for the BSP.
    if (lapic_id <= 0 || lapic_id >= NR_CPUS)
    {
        printk("__ap_kmain_imp: lapic_id\n");
        goto fail;
    }

    // Setup some information in the lapic_info structure for this core
    // #ps:
    // Probably some elements were already set by the BSP before calling this AP.
    // see: apic.c

    int hw_id = (int) apic_get_id(lapic_id);
    lapic_info[lapic_id].local_id = (int) (hw_id & 0xFF);
    printk("AP_kmain: HW ID %d\n", hw_id);

    int localversion = (int) apic_get_version(lapic_id);
    lapic_info[lapic_id].local_version = (int) (localversion & 0xFF);
    printk("AP_kmain: VERSION %x\n", localversion);

    apic_mark_cpu_as_running(lapic_id);  // The Core 1 is running now.
    printk("AP_kmain: Core %d is RUNNING ... :)    <<<< \n", lapic_id);

    // #test: 
    // Increment the counter of AP arunning
    // This job was dome by main.c

    smp_info.nr_ap_running++;

// ===============================

// Setup the GS base for a given core
// We're gonna use it to point to the cpu_locals structure for this core.
// This way we can retrieve the current core's id.
// see:
// x64.h, x64.c and x64smp.c
// #ps:
// We already have an early initialization done in assembly.
// Maybe we can check the values to compare them.

    x64_setup_cpu_local(lapic_id);

// Setup the usage of syscall in long mode for this AP core
// #todo: Pick an address for the syscall handler for this AP core.

    // x64_setup_syscall64( (unsigned long) &systemcall64 );

// =================================================================

// Initialize the GDT and the proper TSS for this core
// IN: 
// + index for lapic_info[i] table
// + ring 0 stack base for the TSS that belongs to this core
// + gdt
// + gdtr

// We cannot change the same GDT used by the BSP core.
// Maybe we can simply load it for the AP.
// We need a new gdt address for the GDT the belongs to the AP.

    static struct segment_descriptor_d ap_gdt[DESCRIPTOR_COUNT_MAX];
    static struct gdt_ptr_d ap_gdtr;

    void *r0_stack;
    r0_stack = kmalloc(4096);
    if (!r0_stack)
        panic("AP: r0_stack");

    x64_init_ap_gdt(
        lapic_id,
        (unsigned long)r0_stack + 4096,
        ap_gdt,
        &ap_gdtr );

// ======================================================================


//
// Thread
//

// #test
// Create the first thread for this code.
// + ring 0
// + not preemptable (for now)
// + ...
// #ps: For now we are simply creating it, not dispatching it.

    unsigned long stack_base =
        (unsigned long) kmalloc(4096);
    unsigned long entry_point = 
        (unsigned long) &__ap_r0_idle_loop;
    ppid_t OwnerPID = GRAMADO_PID_KERNEL;

    struct thread_d *t =
        create_thread(
            THREAD_TYPE_SYSTEM,
            NULL,
            entry_point,
            stack_base + 4096,
            OwnerPID,
            "ap-thread-r0",
            RING0 
        );

    // #debug
    if ((void*) t == NULL)
        x_panic("__ap_kmain_imp: t");

// Link it to this lapic id
    t->current_processor = lapic_id;

//
// Idle thread and idle process
//

    lapic_info[lapic_id].idle_tid = (tid_t) t->tid;
    lapic_info[lapic_id].idle_pid = (pid_t) t->tgid;

//
// Current thread and current process
//

    lapic_info[lapic_id].current_tid = (tid_t) t->tid;
    lapic_info[lapic_id].current_pid = (pid_t) t->tgid;


// This is what i am gonna do after the thread creation 
// just as a safe measure ... 
// in the case this thread eventually reaches the task swtiching

    t->is_preemptable = UNPREEMPTABLE;

// Setup the IRQL for this core
// see: irql.h

    lapic_info[lapic_id].irql = IRQL_NULL;



/*
This is the current situation

BSP
  Timer IRQ
  Preemption
  Scheduler

AP
  No timer scheduling yet
  Dedicated thread
  Runs forever
*/


// ===============================

//
// Go to the dummy thread
//

    __ap_r0_idle_loop();


// Something went wrong with this AP.
// #todo:
// Call a system routine in order to report this.

fail:
    while (1){
        asm (" cli ");
        asm (" hlt ");
    };
}


//
// #
// Main function (For AP processor)
//

void AP_kmain(void)
{
    __ap_kmain_imp();
}




