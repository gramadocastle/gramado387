// fslib.c
// File system support.
// The workers and the real implementation for the services
// called by fs.c.
// Created by Fred Nora.

#include <kernel.h>

// Buffers for 8 directories. Each one with 512 entries.
// 32*512 = 16384
// 16KB
// 16384/4096 = 4 pages.
// ------------------
// with 8 pages we have 8 directories for 1024 entries each dir.

// These are directory buffers, used when walking through a pathname.
// Helps you find the file by walking directories.
unsigned long fs_buffers[FS_N_BUFFERS];

//see: fs.h
struct filesystem_d  *root;

// gcc -Wall Defined but not used!
static char *____root_name = "/";

struct cwd_d  CWD;


// ========================================

//
// == Private functions: Prototypes ===========
//

static int __initialize_fs_buffers(void);
// ...

//=============================


// Local
// The buffers used to load the directories
// when loading a path.
// Buffers
// Buffers for loading the directories while walking on a pathname
// when loading a file.
// 0=ok | <0 = fail.
static int __initialize_fs_buffers(void)
{
    register int i=0;
// The max number of levels in a path.
    size_t Max = FS_N_BUFFERS;
// 512 entries = 16KB.
// 32*512 = 16KB.
    const int PagesPerBuffer = 4;
    unsigned long TmpAddr=0;

// #bugbug
// At this moment we don't have a process defined as current
// and that information is used in the routine allocPages()

// #bugbug
// 4 pages per level.
    for (i=0; i<Max; i++)
    {
        TmpAddr = (unsigned long) allocPages(PagesPerBuffer);
        if ((void*) TmpAddr == NULL){
            goto fail;
        }
        // Important: Zero the memory!
        //memset((void*)va, 0, 4096 * 4);
        fs_buffers[i] = (unsigned long) TmpAddr;
    };

    return 0;
fail:
    return (int) -1;
}


void 
fs_load_boot_metafile (
    unsigned long buffer, 
    unsigned long first_lba, 
    unsigned long size_in_sectors )
{

// #ps: Only on ATA disk
// See: atadsk_r.c

    atadsk_load_boot_metafile(
        buffer,
        first_lba,
        size_in_sectors 
    );
}

void 
fs_store_boot_metafile (
    unsigned long buffer, 
    unsigned long first_lba, 
    unsigned long size_in_sectors )
{

// #ps: Only on ATA disk
// See: atadsk_w.c

    atadsk_store_boot_metafile(
        buffer,
        first_lba,
        size_in_sectors
    );
}


// File read.
// It's called by sys_read.
// Copia à partir do início do arquivo.
// OUT: number of read bytes.
int file_read_buffer( file *f, char *buffer, int len )
{
// Limits:
// We're reading from the file structure,
// The buffer in the file structure is BUFSIZ (1024 for now)
// at minimum.

    char *p;
    int Count=0;

    p = buffer;
// #test
    Count = (int) (len & 0xFFFF);

// Check file
    if ((void *) f == NULL){
        printk ("file_read_buffer: f\n");
        goto fail;
    }
    if ( f->used != TRUE || f->magic != 1234 ){
        printk ("file_read_buffer: f validation\n");
        goto fail;
    }
// Check buffer
    if ((void *) p == NULL){
        printk ("file_read_buffer: p\n");
        goto fail;
    }
// nada para ler.
    if (Count <= 0){
        printk ("file_read_buffer: Count <= 0\n");
        goto fail;
    }
// Chech len
// #bugbug: Isso é provisório
// A quantidade que desejamos ler é menor que o tamanho do buffer.
// Estamos lendo do início do arquivo?
    if (Count > f->_lbfsize)
    {
        //printk ("file_read_buffer: Count > f->_lbfsize\n");
        // printk ("file_read_buffer: Count={%d} > f->_lbfsize={%d} f->_fsize={%d}\n",
            // Count, f->_lbfsize, f->_fsize );

        // #test:
        // Ajust to read only the available bytes in the buffer. 
        Count = f->_lbfsize;

        // goto fail;
    }

    //if ( Count > f->_fsize ){
        //printk ("file_read_buffer: Count > f->_fsize\n");
    //    Count = f->_fsize;
    //    goto fail;
    //}

    // #debug
    // printk ("file_read_buffer: Count={%d} > f->_lbfsize={%d} f->_fsize={%d}\n",
        // Count, f->_lbfsize, f->_fsize );

/*
// stdin
    if( f->_file == 0 )
    {
        if( f->_lbfsize != PROMPT_SIZE)
        {
           printk ("file_read_buffer: [FAIL] Wrong size for stdin _lbfsize\n");
           goto fail;
        }
    }
 */

//=======================================
// Copy!
// #todo
// nao podemos ler mais que o limite do arquivo.
// A próxima leitura precisa ser depois dessa.

// =================================
// Socket:
// Se o arquivo é um socket, 
// então não concatenaremos escrita ou leitura.
// You also can write now.
// But i can still read.
    if (f->____object == ObjectTypeSocket){
        memcpy ( (void *) buffer, (const void *) f->_base, Count );
        f->_flags |= __SWR;
        return (int) Count;
    }

// =================================
// Pipe:
// Não concatenaremos
// You also can write now.
// But i can still read.
    if (f->____object == ObjectTypePipe)
    {
        // #backup: Old implementation
        // memcpy ( (void *) buffer, (const void *) f->_base, Count );
        // f->_flags |= __SWR;
        // return (int) Count;

        // #test: New implementation
        return (int) file_read_pipe_buffer(f, buffer, Count);
    }

// =================================
// Regular file, tty, iobuffer.
// Nesse caso a leitura tem que respeitar os offsets e limites.
// #todo:
// We can create an IF for each one of these types.
    if ( f->____object == ObjectTypeFile ||
         f->____object == ObjectTypeTTY  ||
         f->____object == ObjectTypeIoBuffer)
    {
        // Se o buffer tem tamanho 0.
        if (f->_lbfsize <= 0){
            printk ("file_read_buffer: _lbfsize is 0\n");
            goto fail;
        }

        // Se o tamanho do buffer for maior que o padrão.
        // #todo: O buffer pdoerá ser maior que isso no futuro.
        //if ( f->_lbfsize > BUFSIZ ){
        //    printk ("file_read_buffer: _lbfsize\n");
        //    goto fail;
        //}

        // #test: Limite provisorio
        if (f->_lbfsize > (8*1024)){
            printk ("file_read_buffer: _lbfsize bigger than 8KB\n");
            goto fail;
        }

        // Não podemos ler antes do início do arquivo.
        if ( f->_r < 0 ){
            f->_r = 0;
            printk ("file_read_buffer: f->_r = 0\n");
            goto fail;
        }

        // Nao leremos depois do fim do arquivo.
        if ( f->_r > f->_lbfsize )
        {
            //#debug: provisorio
            printk ("file_read_buffer: f->_r > f->_lbfsize\n");
            goto fail;
            //debug_print("file_read_buffer: f->_r > f->_lbfsize\n");
            //f->_r = f->_lbfsize;
            //f->_w = f->_lbfsize;
            //f->_p = (f->_base + f->_lbfsize);
            //f->_cnt = 0;
            //return EOF;
        }

        // Se o offset de leitura for maior que
        // o offset de escrita, então temos que esperar.
        // #bugbug: mas talvez isso não seja assim para pipe.
        if (f->_r > f->_w)
        {
            // EOF
            printk ("file_read_buffer: f->_r > f->_w\n");
            //goto fail;
            //debug_print("file_read_buffer: f->_r > f->_w\n");
            f->_r = f->_w;
            //faremos o ajuste logo abaixo.
            //f->_p = (f->_base + f->_r);
            // You also can write now.
            // But i can still read.
            //f->_flags = __SWR;
            return 0;
        }

        // Se a quantidade que desejamos ler
        // é maior que o espaço que temos.
        // # Isso ja foi feito logo acima.
        if (Count > f->_lbfsize)
        {
            //printk ("file_read_buffer: Count > f->_lbfsize\n");
            //goto fail;

            //printk ("file_read_buffer: [FAIL] local_len limits\n");
            //goto fail;
        
            //#test #bugbug
            // leia tudo então. hahaha
            Count = (f->_lbfsize - 1);
        }

        // Se o tanto que queremos ler é maior
        // que o que nos resta da buffer,
        // então vamos ler apenas o resto do buffer.

        // #bugbug: Isso esta errado. #delete

        // So podemos ler ate limite de bytes disponíveis 
        // no buffer.
        //if (Count > f->_cnt)
        //{
            //printk ("file_read_buffer: local_len > f->_cnt\n");
            //goto fail;
            //Count = f->_cnt;
        //}
 
        // 
        int delta = (f->_w - f->_r);

        // nada para ler.
        // pois o ponteiro de escrita e o de leitura sao iguais,
        if (delta == 0){
            // 0 bytes lidos
            //printk ("delta=0\n");
            return 0;
        }
 
        // #delta
        // Se o tanto que queremos ler
        // é maior que o tanto que foi efetivamente escrito,
        // então leremos somente o que foi escrito.
        // se a diferença entra o ponteiro de escrita e o ponteiro
        // de leitura for menor que a quantidade que queremos ler.
        // Se queremos ler mais do que foi escrito.
        // entao vamos ler apenas o que foi escrito.
        if (Count > delta){
            Count = delta;
        }

        // Atualizando o ponteiro de trabalho.
        // Vamos ler daqui.
        // A partir do offset de leitura.
        f->_p = (f->_base + f->_r);

        // read

        //#debug
        if (Count <= 0){
            printk ("file_read_buffer: Count <= 0 SECOND\n");
            goto fail;
            //printk("local_len\n");
            //return -1;
        }

        // Copy from the address pointed by the file structure
        // to a given ring3 or ring0 buffer.
        // The file structure has the limit of BUFSIZ.
        memcpy (
            (void *) buffer, 
            (const void *) f->_p, 
            Count ); 

        // Atualizamos o ponteiro de trabalho
        f->_p = (f->_p + Count);

        // Atualizamos o offset de leitura.
        // Ele é usado em relação à base.
        // #bugbug: Talvez essa leitura e escrita devesse ser em relação
        // ao ponteiro de trabalho.
        f->_r = (f->_r + Count);

        if ( f->_r > f->_w ){
            f->_r = f->_w;
        }

        // You also can write now.
        // But i can still read.
        f->_flags |= __SWR;
        f->sync.can_write = TRUE;

        return (int) Count;
    }

fail:
    return EOF;
}

/*
 * file_write_buffer: 
 * Escreve no arquivo uma certa quantidade 
 * de caracteres de uma dada string.
 */
// Escreve no arquivo uma certa quantidade de caracteres 
// de uma dada string.
// It's called by sys_write.
// OUT: number of written bytes.
int 
file_write_buffer ( 
    file *f, 
    char *string, 
    int len )
{
    char *p;

// #todo:
// p = string; → but you never use p (you use string directly in memcpy)
    p = string;

    // debug_print ("file_write_buffer:\n");

// File validation
    if ((void *) f == NULL){
        printk ("file_write_buffer: f\n");
        goto fail;
    }
    // #todo: Check used and magic.
    //if (f->magic != 1234)
        //return -1;

    if ((void *) p == NULL){
        printk ("file_write_buffer: p\n");
        goto fail;
    }

// Tentando escrever mais do que cabe no arquivo.
// #bugbug:
// We already have support for larger buffer.
// Lets check agains the buffer actual size.
    // if (len >- f->_blksize)  // #todo
    if (len >= BUFSIZ)
    {
        printk ("file_write_buffer: len >= BUFSIZ\n");
        goto fail;
    }

//
// Copy
//

// Socket file.
// #ps: Write it directly into the base.
// Se o arquivo é um socket, então não concatenaremos 
// escrita ou leitura.

    if (f->____object == ObjectTypeSocket){
        memcpy( (void *) f->_base, (const void *) string, len );
        return (int) len;
    }

// Pipe file.
// não concatenaremos
    if (f->____object == ObjectTypePipe)
    {
        // #backup: Old implementation
        // memcpy( (void *) f->_base, (const void *) string, len );
        // return (int) len;

        // #test: New implementation
        return (int) file_write_pipe_buffer(f, string, len);
    }

// Regular file, TTY file, IO Buffer file.
// Tem que atualizar o ponteiro para que o próximo
// write seja depois desse write.
// Para isso o ponteiro precisa estar no base quando
// o write for usado pela primeira vez.
// Mas se o write for usado num arquivo aberto com 
// open(), então o ponteiro deve estar no fim do arquivo.
// Isso não significa que está no fim do buffer.
// Nesse caso o aplicative deveria usar rewind() antes
// para ter um ponteiro de escrita adequado.

    if ( f->____object == ObjectTypeFile ||     // regular file
         f->____object == ObjectTypeTTY  ||     // tty
         f->____object == ObjectTypeIoBuffer )  // ??
    {
        // #bugbug
        // Temos que ter um limite aqui ... !!!
        // #todo

        // se o tamanho do buffer for maior que o padrao.
        if (f->_lbfsize > BUFSIZ){
            printk ("file_write_buffer: _lbfsize\n");
            goto fail;
        }
    
        if (f->_w < 0)
        {
            f->_p = f->_base;
            f->_w = 0;
            f->_r = 0;
            f->_cnt = f->_lbfsize;
            return EOF;
        }

        // Se o offset de escrita ultrapassa os limites.
        if (f->_w >= BUFSIZ)
        {
            //#bugbug
            debug_print("file_write_buffer: f->_w >= BUFSIZ\n");
            printk     ("file_write_buffer: f->_w >= BUFSIZ\n");
            f->_w = BUFSIZ;
            f->_cnt = 0;
            return EOF;
        }

        //if ( f->_w 

        // recalculando quanto espaço temos.
        //f->_cnt = (f->_lbfsize - f->_w);

        // Se a quantidade que temos ultrapassa os limites.

        // fim do arquivo.
        if (f->_cnt < 0)
        {
            f->_cnt = 0;
            f->_w = f->_lbfsize;
            f->_r = f->_lbfsize;
            f->_p = (f->_base + f->_w);
            return EOF;
        }

        // Inicio do arquivo
        if (f->_cnt > f->_lbfsize)
        {
            printk ("file_write_buffer: _cnt\n");
            f->_cnt = f->_lbfsize;
            f->_p = f->_base;
            f->_w = 0;
            f->_r = 0;
        }

        if (len < 0){
            return (int) -1;
        }

        // Se o que desejamos escrever é maior que o espaço que temos.
        if (len > f->_cnt)
        {
            // Estamos no fim do arquivo
            if ( f->_cnt <= 0 )
            {
                f->_w = f->_lbfsize;
                f->_r = f->_lbfsize;
                f->_p = f->_base + f->_lbfsize;
                f->_cnt = 0;
                return (int) -1;
            }

            // Só podemos escrever esse tanto.
            if ( f->_cnt > 0 ){
                len = f->_cnt; 
            }
        }

        // write.
        // Se o offset de escrita é menor que o offset de leitura.
        // Então adiantaremos o offset de escrita.
        // pois nao devemos tocar no offset de leitura.
        if (f->_w < f->_r)
        {
            f->_w = f->_r;
            f->_cnt = ( f->_lbfsize - f->_w );
        }

        // Update the pointer
        f->_p = (f->_base + f->_w);

        // Write it, using the pointer
        memcpy( (void *) f->_p, (const void *) string, len ); 
    
        // Update the pointer
        f->_p = (f->_p + len);

        // Update the offset for writing
        f->_w = (f->_w + len);
    
        // Atualizamos o quanto nos falta.
        f->_cnt = (f->_cnt - len);
        
        // You can read now.
        f->_flags = __SRD;
        f->sync.can_read = TRUE;

        //debug_print ("file_write_buffer: ok, done\n");

        // Retornamos a quantidade escrita no buffer.
        return (int) len;
    }

// Unknown type
fail:
    //printk ("file_write_buffer: fail\n");
    return EOF;
}

// __read_imp
// It implements the service for read() syscall.
// ring0 read() implementation.
// Service 18.
// #todo: There's a lot to do with synchronization.
// #todo
// We need to call one subfunctions for
// each different kind of file intead of implementing
// an internal sub-routine.
// #todo
// Isso deveria ser apenas um wrapper,
// chamando as rotinas apropriadas para cada tipo 
// de arquivo.
// OUT:
// 0 = Couldn't read.
// -1 = Error.
// return 'ssize_t'?

ssize_t 
__read_imp (
    int fd,
    char *ubuf,       //#todo: use 'void *'
    size_t count )
{

// The system can now open and allocate buffers for larger files (like 5KB), 
// but the read path is still capped at 1KB because of leftover hardcoded checks.
// Probably we are capping it inside the kernel AND in the C libraries in ring 3.

// Limits:
// #test
// Probably we can extand the limit to BUFSIZ,
// Because this is the limit used by the sys_open().
// #test: 
// So, let's try to accept a user buffer 
// with the limit up to BUFSIZ.

// #: It needs to be used only as a worker for syscalls.
// #todo
// Get the processor pointer
// and increment the read operation counter for this process.

// File pointer.
    file *fp;

    ssize_t nbytes=0;
    struct socket_d *s;
    //#bugbug: We don't know the size of the user buffer.
    //size_t ubuf_len=0;  // # Out limit is BUFSIZ

//-----------------------------
    struct te_d *p;

    // Get PID for the current process for a given core.
    // IN: core id

    pid_t current_process = (pid_t) get_current_process(0);

// Process
// #todo: There is a helper for that small routine.
    if (current_process < 0 || current_process >= PROCESS_COUNT_MAX)
    {
        debug_print("__read_imp: current_process\n");
        goto fail;
    }
    p = (void *) teList[current_process];
    if ((void *) p == NULL){
        debug_print("__read_imp: p\n");
        goto fail;
    }
    if ( p->used != TRUE || p->magic != 1234 ){
        debug_print("__read_imp: p validation\n");
        goto fail;
    }
// #warning
// The goal here is counting how many timer the operation was called.
    p->read_counter++;
//-----------------------------

// #bugbug
// O argumento é 'unsigned int'.
// Deveria ser int?

// fd
    if (fd < 0 || fd >= OPEN_MAX){
        return (ssize_t) (-EBADF);
    }
// ubuf
// todo: Checar a validade da região de memória.
    if ((void *) ubuf == NULL){
        return (ssize_t) (-EINVAL);
    }
// count
    if (count < 0){ 
        return (ssize_t) (-EINVAL);
    }
// Nothing to do.
    if (count == 0){ 
        return 0; 
    }

// Size of the buffer.
// #test: Our limit is BUFSIZ (1024) for now.
    //ubuf_len = strlen((const char *) ubuf);
    //ubuf_len = sizeof((const char *) ubuf);

// The user wants to read more than the size of the 
// buffer provide by him.
// Se a quantidade desejada é maior que o buffer disponível.
    //if (count > ubuf_len)
    //{
        //serial_printk ("__read_imp: count=%d ubuf_len=%d\n",
        //count, ubuf_len );
        // #test
        //panic("__read_imp: ubuf is not enough");
    //}

// Se o buffer disponível é maior que a quantidade desejada
// então não temos problemas, nem precisamos disso. 
    //if (ubuf_len > count){
        //ubuf_len = count;
    //}

// #fixme: 
// The buffer is too small.
// #todo
// We want a bigger limit for reading,
// we will read a socke with this routine,
// use the stadard size for a socket at least.
// See: SO_SNDBUF and SO_RCVBUF
// #ps:
// Actually this routine can be able to read files
// bigger than a socket.

    //if (ubuf_len > 512){
        //debug_print ("__read_imp: ubuf_len\n");
        //ubuf_len = 512;
    //}

// File
// Get the object pointer.
// #warning: For the current process.
    fp = (file *) get_file_from_fd(fd);
    if ((void *) fp == NULL)
    {
        debug_print("__read_imp: fp\n");
        printk     ("__read_imp: fp\n");
        goto fail; 
    }

    if (fp->sync.can_read != TRUE){
        debug_print("__read_imp: Permission\n");
        printk     ("__read_imp: Permission\n");
        goto fail; 
    }

/*
    // #todo
    // ainda nao inicializamos esse elemento.
    if( fp->is_readable == FALSE ){
        debug_print ("__read_imp: Not readable\n");
        return -1;
    }
*/

    // #todo: Create thie element in the structure.
    // if( fp->is_directory == TRUE ){}

//
// ------------------------------------------------------------
//  READ FROM STDIN  (fd = 0)
// ------------------------------------------------------------
//
//  This block handles read() calls directed at STDIN.
//
//  In Gramado, STDIN is typically backed by a Virtual Console
//  (TTY). Reading from STDIN means pulling characters from the
//  TTY input subsystem, which may contain:
//      • real keyboard input,
//      • injected input (INIT → ds00 → GUI apps),
//      • PTY‑style redirected input.
//
//  Behavior:
//
//  1. If STDIN is a Virtual Console (TTY):
//       - fp->tty must be non‑NULL.
//       - __tty_read() copies bytes from the TTY input queue
//         into the user buffer.
//       - The TTY layer decides blocking vs non‑blocking
//         behavior and how many bytes are returned.
//
//  2. If STDIN is a regular file:
//       - Fall through to the RegularFile handler.
//
//  3. Any other object type is invalid for STDIN reads.
//
//  Notes:
//
//    • Permission enforcement (sync.can_read) and the foreground
//      thread restriction are handled earlier in sys_read().
//
//    • __tty_read() is the authoritative source of terminal input.
//      It merges real keyboard events and programmatically injected
//      input into a single unified queue.
//
//    • If fp->tty is NULL, the STDIN stream is misconfigured.
//
// ------------------------------------------------------------

    if (fp->_file == STDIN_FILENO){
        if (fp->____object == ObjectTypeVirtualConsole)
        {
            if (fp->tty != NULL) 
            {
                nbytes = (ssize_t) __tty_read(fp->tty,ubuf,count);
                return (ssize_t) nbytes;               
            }
            if (fp->tty == NULL){
                //printk("0:: tty null\n");
                return (ssize_t) -1;
            }
        }
        if (fp->____object == ObjectTypeFile){
            goto RegularFile;
        }
        if (fp->____object == ObjectTypeTTY){
            goto tty_object;
        }
    }

//
// ------------------------------------------------------------
//  READ FROM STDOUT  (fd = 1)
// ------------------------------------------------------------
//
//  This block handles read() calls directed at STDOUT.
//
//  In Gramado, STDOUT is normally bound to a Virtual Console
//  (TTY) and is therefore a write‑only stream. Reading from a
//  TTY‑backed STDOUT is not supported and will fail, matching
//  the behavior of UNIX/POSIX systems.
//
//  Behavior:
//
//  1. If STDOUT is a Virtual Console (TTY):
//       - fp->tty must be non‑NULL.
//       - STDOUT is write‑only when attached to a TTY.
//       - read() returns an error (‑1), since there is no
//         mechanism to read from the TTY output queue.
//
//  2. If STDOUT is a regular file:
//       - Fall through to the RegularFile handler.
//       - read() returns data from the file, which is valid
//         when STDOUT has been redirected (e.g., "cmd > file").
//
//  3. Any other object type is invalid for STDOUT reads.
//
//  Notes:
//
//    • This matches POSIX semantics: reading from a terminal's
//      stdout stream is undefined and typically fails with
//      EBADF in user space.
//
//    • Redirection makes STDOUT readable because it becomes a
//      normal file descriptor backed by a file object.
//
//    • If fp->tty is NULL, the STDOUT stream is misconfigured.
//
// ------------------------------------------------------------

    if (fp->_file == STDOUT_FILENO)
    {
        if (fp->____object == ObjectTypeVirtualConsole)
        {
            if (fp->tty != NULL) 
            {
                // stdout is write-only when bound to a TTY.
                // Reading from it is not supported.
                //printk("read(stdout): TTY is write-only\n");
                return (ssize_t) -1;
            }
            if (fp->tty == NULL){
                //printk("1:: tty null\n");
                return (ssize_t) -1;
            }
        }
        if (fp->____object == ObjectTypeFile){
            goto RegularFile;
        }
        if (fp->____object == ObjectTypeTTY){
            goto tty_object;
        }
        goto fail;
    }

//
// ------------------------------------------------------------
//  READ FROM STDERR  (fd = 2)
// ------------------------------------------------------------
//
//  This block handles read() calls directed at STDERR.
//
//  In Gramado, STDERR is normally bound to a Virtual Console
//  (TTY) and is therefore a write‑only stream. Reading from a
//  TTY‑backed STDERR is not supported and will fail, matching
//  the behavior of UNIX/POSIX systems.
//
//  Behavior:
//
//  1. If STDERR is a Virtual Console (TTY):
//       - fp->tty must be non‑NULL.
//       - STDERR is write‑only when attached to a TTY.
//       - read() returns an error (‑1), since there is no
//         mechanism to read from the TTY output queue.
//
//  2. If STDERR is a regular file:
//       - Fall through to the RegularFile handler.
//       - read() returns data from the file, which is valid
//         when STDERR has been redirected (e.g., "cmd 2> file").
//
//  3. If STDERR is a pipe:
//       - The pipe read path will handle this case.
//       - This allows constructs like "cmd 2> >(another_program)".
//
//  4. Any other object type is invalid for STDERR reads.
//
//  Notes:
//
//    • This matches POSIX semantics: reading from a terminal's
//      stderr stream is undefined and typically fails with
//      EBADF in user space.
//
//    • Redirection makes STDERR readable because it becomes a
//      normal file descriptor backed by a file object.
//
//    • If fp->tty is NULL, the STDERR stream is misconfigured.
//
// ------------------------------------------------------------

    if (fp->_file == STDERR_FILENO)
    {
        if (fp->____object == ObjectTypeVirtualConsole)
        {
            if (fp->tty != NULL)
            {
                // stderr is write-only when bound to a TTY.
                // Reading from it is not supported.
                //printk("read(stderr): TTY is write-only\n");
                return (ssize_t) -1;
            }
            if (fp->tty == NULL){
                //printk("2:: tty null\n");
                return (ssize_t) -1;
            }
        }
        if (fp->____object == ObjectTypeFile){
            goto RegularFile;
        }
        if (fp->____object == ObjectTypeTTY){
            goto tty_object;
        }
        goto fail;
    }


//
// == Socket file ===========================================
//

// ==== Socket =======================
// Se o arquivo for um socket.
// #todo: 
// Now we can call socket_read(...)

    if (fp->____object == ObjectTypeSocket)
    {
        // debug_print("__read_imp: [DEBUG] Trying to read a socket object\n");
        do_credits_by_tid( lapic_info[0].current_tid );

        PROGRESS("SOCKET OBJECT\n");

        // -- Below is for remote connections ------------
        // Check the socket validation and state
        // Receive data to a REMOTE peer.
        // We get the connection information based on the client's socket.
        // Established AF_INET → real TCP recv.
        struct socket_d *sk = fp->socket;
        if ((void*)sk == NULL)
            PROGRESS("Invalid sk");
        if ((void*)sk != NULL)
        {
            if ( sk->magic == 1234 && 
                 sk->family == AF_INET && 
                 sk->state == SS_CONNECTED )
            {
                if (sk->is_client_connecting_with_remote_server == TRUE)
                {
                    //if (fp->sync.can_read != TRUE)
                    //    return 0;
                    PROGRESS("SOCKET calling worker\n");
                    
                    // see: tcp.c
                    // It is working
                    int n = tcp_socket_recv(sk, ubuf, count);
                    if (n < 0){
                        return (int) -1;
                    }
                    return (int) n;  // 0 = no data yet (non-blocking style)
                }

                if (sk->is_remote_client_connecting_with_local_server == TRUE)
                {
                    //if (fp->sync.can_read != TRUE)
                    //    return 0;
                    printk("SOCKET calling worker\n");
                    // see: tcp.c
                    // It is working
                    int n = tcp_socket_recv(sk, ubuf, count);
                    if (n < 0){
                        return (int) -1;
                    }
                    return (int) n;  // 0 = no data yet (non-blocking style)
                }
            }
        }


        // not reading yet
        if ((fp->_flags & __SRD) == 0) 
        {
            //debug_print("__read_imp: [FAIL] flag __SRD \n");
            //yield (lapic_info[0].current_tid);
            goto fail;
        }

        nbytes = 0;

        // vazio? 
        // nao podemos ler.
        // acorda escritores e dorme.
        if (fp->socket_buffer_full == FALSE)
        { 
            debug_print("__read_imp: [FAIL] can't read an empty buffer\n");
            //goto fail;
            
            // #debug
            // debug_print("__read_imp: WAKEUP WRITER\n");
            
            fp->_flags = 0;
            fp->_flags |= __SWR;                  // pode escrever
            //do_thread_ready( fp->tid_waiting );   // acorda escritores. 
            //fp->tid_waiting = -1;

            // #bugbug
            // Isso pode ser ruim pela natureza da chamada sys_read()
            // que vem de uma syscall que nao salvou o contexto.

            if (fp->sync.block_on_read_empty == TRUE)
            {
                debug_print("__read_imp: SLEEP READER\n");
                panic("__read_imp: [DEBUG] Couldn't read socket. Buffer not full\n");

                //fp->tid_waiting = lapic_info[0].current_tid;
                //do_thread_waiting (lapic_info[0].current_tid);
                yield (lapic_info[0].current_tid);
                goto fail;
            }
            yield (lapic_info[0].current_tid);
            goto fail;
        }

        // cheio? 
        // le e acorda escritores.
        if (fp->socket_buffer_full == TRUE)
        {
            if (fp->_flags & __SRD)
            {
                //debug_print ("__read_imp: >>>> READ\n");
            
                // Read from the file structure to the 
                // user buffer. The limit in the file structure
                // is BUFSIZ (1024 for now)
                nbytes = 
                    (ssize_t) file_read_buffer ( 
                                  (file *) fp, 
                                  (char *) ubuf, 
                                  (int) count );

                if (nbytes <= 0){
                    debug_print("__read_imp: [FAIL] file_read_buffer fail when reading a socket \n");
                    //yield (lapic_info[0].current_tid);
                    goto fail;
                }

                // ok
                if (nbytes > 0)
                {
                    //debug_print("__read_imp: [DEBUG] lemos mais que 0 bytes em um socket.\n");
                    fp->socket_buffer_full = FALSE;     // buffer vazio
                    fp->_flags &= ~__SRD;  // nao posso mais LER.            
                    fp->_flags |= __SWR;   // pode escrever também
                    //debug_print("__read_imp: WAKEUP WRITER\n");
                    //do_thread_ready( fp->tid_waiting );  // acorda escritores.
                    //fp->tid_waiting = -1;
                    //debug_print("__read_imp:done\n");

                    return (ssize_t) nbytes;    // bytes escritos.
                }
            }
        } 

        panic ("__read_imp: Unexpected error when reading socket\n");
    }

//
// == Regular file ============================================
//

// ==== Regular file =======================
// Read a regular file.
// See: unistd.c
// #todo Tem que retornar a quantidade de bytes lido.
// #bugbug: Nem todos arquivos criados possuem essa flag configurada
// apropriadamente ...estamos fazendo isso.
// #hackhack
// We will open all the other kind of object
// with this IF right here.
// We need to fix it in the open() routines
// to give us the correct type.

RegularFile:

    if (fp->____object == ObjectTypeFile)
    {

         //#debug
         //if( fp->_file == 5)
         //{
         //    if ( (fp->_flags & __SRD) == 0 )
         //        printk("cant read\n");
         //    if ( fp->_flags & __SRD )
         //        printk("can read\n");
         //    printk("__read_imp-OUTPUT 5: %s \n",fp->_base);
         //}

        //debug_print("__read_imp: [DEBUG] Trying to read a regular file object\n");
        
        //Se não pode ler.
        if ( (fp->_flags & __SRD) == 0 )
        {
            //debug_print("__read_imp: [FLAGS] Can't read!\n");
        
            //Não conseguimos ler.
            //nada de errado, apenas espera.
            //do_thread_waiting (lapic_info[0].current_tid);
            //fp->tid_waiting = lapic_info[0].current_tid;
            //fp->_flags |= __SWR;  //pode escrever.
            //scheduler();

            //printk("__read_imp: fp->_flags & __SRD \n");
            goto fail;
        }
        
        nbytes = 0;

        // Se puder ler:
        // + Call a function to read a regular file.
        // + Sinalize that another process can write.
        // #todo: wake the one that was waiting to write.

        if (fp->_flags & __SRD)
        {

            // Read from the file structure to the 
            // user buffer. The limit in the file structure
            // is BUFSIZ (1024 for now)

            nbytes = 
                (ssize_t) file_read_buffer ( 
                              (file *) fp, 
                              (char *) ubuf, 
                              (int) count );
 
            if (nbytes <= 0){
               //yield (lapic_info[0].current_tid);
               goto fail;
            }

            // Se conseguimos ler.
            if (nbytes>0)
            {
                //fp->_flags &= ~__SRD;  // nao posso mais LER.            
                //fp->_flags |= __SWR;   // pode escrever também
                // ok to write.
                fp->_flags |= __SWR;
                fp->sync.can_write = TRUE;
                // #test
                // Acordar quem esperava por esse evento
                //do_thread_ready( fp->tid_waiting );
                return (ssize_t) nbytes; 
            }

            //Não conseguimos ler.
            //nada de errado, apenas espera.
            //do_thread_waiting (lapic_info[0].current_tid);
            //fp->tid_waiting = lapic_info[0].current_tid;
            //fp->_flags |= __SWR;  //pode escrever.
            //scheduler();
            return 0;
        }

        // #todo
        // Do we need something here ?
        //return -1;
    }

// ========================================
// Pseudo terminal multiplexer.

    if (fp->____object == ObjectTypePTMX){
        printk ("__read_imp: [TODO] trying to read a PTMX device file\n");
        return 0;
    }

// ========================================
// PTY (pseudo terminal) read path
//
// FULL DUPLEX MODEL:
//
// 1) MASTER reads from its output queue
//    - This is data written by the slave (shell output)
//
// 2) SLAVE reads from its input queue
//    - This is data written by the master (terminal input)
//
// Subtypes:
//    TTY_SUBTYPE_PTY_MASTER  = PTY master endpoint
//    TTY_SUBTYPE_PTY_SLAVE   = PTY slave endpoint

tty_object:
    if (fp->____object == ObjectTypeTTY)
    {
        //printk ("__read_imp: [TODO] trying to read a PTY device file\n");
        if ((void*)fp->tty == NULL)
            return -1;

        // 1) MASTER reads from its output queue
        if (fp->tty->subtype == TTY_SUBTYPE_PTY_MASTER){
            return (ssize_t) __tty_read2(fp->tty,ubuf,count);
        }

        // 2) SLAVE reads from its input queue
        if (fp->tty->subtype == TTY_SUBTYPE_PTY_SLAVE){
            return (ssize_t) __tty_read( fp->tty, ubuf, count );
        }
        return 0;
    }

// ======================================================
// Virtual console (TTY). But NOT the standard streams.

    if (fp->____object == ObjectTypeVirtualConsole)
    {
        if (fd == STDIN_FILENO || 
            fd == STDOUT_FILENO || 
            fd == STDERR_FILENO )
        {
            return -1;
        }

        // Read from that console’s TTY input queue
        if (fp->tty != NULL){
            return (ssize_t) __tty_read(fp->tty, ubuf, count);
        }
        return -EINVAL; 
    }


// ========================================
// file system

    if (fp->____object == ObjectTypeFileSystem){
        printk ("__read_imp: [TODO] trying to read a file system\n");
        return 0;
    }

// ========================================
// See: pipe.c

    if (fp->____object == ObjectTypePipe)
    {
        return (ssize_t) file_read_buffer ( 
                              (file *) fp, 
                              (char *) ubuf, 
                              (int) count );
    }

// ======================================================
    // ...
    debug_print ("__read_imp: [FAIL] Unknown object type\n");
// ==========================================

//
// Fail
//
    
// #bugbug
// See manual for the error:
// https://www.gnu.org/software/libc/manual/html_node/I_002fO-Primitives.html
// http://man7.org/linux/man-pages/man2/read.2.html

// A intenção é que um erro seja representado por -1 e não por 0.
// Zero representará fim de arquivo. 

fail:

    // #debug
    // debug_print ("__read_imp: [FAIL] something is wrong!\n");

// #bugbug: 
// Isso pode degradar o desempenho.

    // printk ("__read_imp: [FAIL] something is wrong!\n");
    //bloqueando, autorizando a escrita e reescalonando.
    //do_thread_waiting (lapic_info[0].current_tid);
    //fp->tid_waiting = lapic_info[0].current_tid;
    //fp->_flags |= __SWR;  //pode escrever      
    //scheduler();  //#bugbug: Isso é um teste  

// Something is wrong
    return (ssize_t) (-1);
}


// __write_imp
// It implements the service for write() syscall.
// Implemantation of write() for libc.
// service 19.
// Copiar um buffer para um arquivo dado o descritor.
// Aqui devemos selecionar o dispositivo à escrever.
// See:
// https://github.com/zavg/linux-0.01/blob/master/fs/read_write.c
// https://linux.die.net/man/2/write
// ...
// #todo
// We need to call one subfunction for each different kind of file 
// intead of implementing an internal sub-routine.

// #todo
// Isso deveria ser apenas um wrapper,
// chamando as rotinas apropriadas para cada tipo 
// de arquivo.

// #todo
// Copiar deve ser uma opcao e nao uma regra!
// Precisamos de uma flag para copyonwrite.
// atençao
// Podemos escrever num socket que nao eh o privado!!!
// existe a possibilidade de o processo atual estar 
// escrevendo em um socket que pertence a outro processo.
// mas que por causa da conexao possui o fd dele registrado
// em sua estrutura.
// Entao o fd passado por argumento nao precisa ser o mesmo
// do socket privado do processo. Pois poderemos estar
// escrevendo em outro socket que nao o privado.
// #: It needs to be used only as a worker for syscalls.
// #todo
// Get the processor pointer
// and increment the write operation counter for this process.

// OUT:
// 0 = Couldn't read.
// -1 = Error.

ssize_t __write_imp (int fd, char *ubuf, size_t count)
{
    file *fp;
//    struct socket_d *s1;
//    struct socket_d *s2;
    struct te_d *p;  // Process structure
    ssize_t nbytes=0;
    size_t ncopy=0;

    //debug_print("__write_imp: :)\n");

// Get PID for the current process for a given core.
// IN: core id

    pid_t current_process = (pid_t) get_current_process(0);
    if (current_process < 0 || current_process >= PROCESS_COUNT_MAX){
        //debug_print("__write_imp: current_process\n");
        goto fail;
    }
    p = (void *) teList[current_process];
    if ((void *) p == NULL){
        //debug_print("__write_imp: p\n");
        goto fail;
    }
    if (p->used != TRUE || p->magic != 1234){
        //debug_print("__write_imp: p validation\n");
        goto fail;
    }

// #warning
// The goal here is counting how many timer the operation was called.
    p->write_counter++;
//-----------------------------

// fd
    if (fd < 0 || fd >= OPEN_MAX){
        return (ssize_t) (-EBADF);
    }
// ubuf
    if ((void *) ubuf == NULL){
        return (ssize_t) (-EINVAL);
    }
// count
    if (count < 0){ 
        return (ssize_t) (-EINVAL);
    }
    // Nothing to do
    if (count == 0){ 
        return 0; 
    }

//
// Size of the buffer
//

// len
    //ubuf_len = strlen((const char *) ubuf);

// Se a quantidade desejada é maior que o buffer disponível.
    //if (count > ubuf_len){
        //debug_print("__write_imp: [FIXME] count too long!\n");
    //}

// se o buffer é maior que a quantidade desejada, 
// então não temos problemas
    //if (ubuf_len > count ){
        //ubuf_len = count;
        //debug_print ("__write_imp: [FIXME] Ajusting ubuf_len\n");
    //}

// #debug: 
// limits
// Um socket tem o tamanho de BUFSIZ.
    //if (ubuf_len > 512){
        //ubuf_len = 512;
        //debug_print ("__write_imp: [FIXME] Ajusting ubuf_len to 512\n");
    //}

// File
// Get the object pointer from the list
// in the process structure.
// #warning: For the current process.
    fp = (file *) get_file_from_fd(fd);
    if ((void *) fp == NULL)
    {
        //debug_print("__write_imp: fp not open\n");
        printk("__write_imp: fp not open #hang\n");
        //printk      ("fd{%d} pid{%d}\n",fd,current_process);
        //printk("entry0: %x\n", __P->Objects[0]);
        //printk("entry1: %x\n", __P->Objects[1]);
        //printk("entry2: %x\n", __P->Objects[2]);
        //printk("entry3: %x\n", __P->Objects[3]);
        //printk("entry4: %x\n", __P->Objects[4]);
        //while(1){}
        goto fail;
    }

    if (fp->sync.can_write != TRUE)
    {
        //debug_print("__write_imp: [PERMISSION] Can NOT write the file\n");
        printk("__write_imp: [PERMISSION] Can NOT write fd={%d} tid={%d}\n", 
            fd, 
            lapic_info[0].current_tid 
        );
        goto fail; 
    }

/*
// #todo
// ainda nao inicializamos esse elemento.
    if( fp->is_writable == FALSE ){
        debug_print ("__write_imp: Not writable\n");
        return -1;
    }
*/

// #todo: 
// Create thie element in the structure.
    //if( fp->is_directory == TRUE ){}

//
// ------------------------------------------------------------
//  WRITE TO STDIN  (fd = 0)
// ------------------------------------------------------------
//
//  This block handles write() calls directed at STDIN.
//
//  In Gramado, STDIN is not strictly read‑only. Certain
//  components (INIT, display server, PTYs, IPC mechanisms)
//  legitimately inject data into STDIN. Therefore, write(0,...)
//  is allowed *if* the underlying file object permits writing.
//
//  Behavior:
//
//  1. If STDIN is backed by a Virtual Console (TTY):
//       - fp->tty must be non‑NULL.
//       - The write is treated as *input injection*.
//       - Bytes are delivered to the TTY input queue via
//         __tty_write(), making them appear as if typed by the user.
//
//  2. If STDIN is a regular file:
//       - Fall through to the RegularFile handler.
//
//  3. Any other object type is invalid for STDIN writes.
//
//  Notes:
//
//    • This path is essential for passing command lines from
//      INIT → display server → GUI apps.
//
//    • __tty_write() is the correct backend for injecting input
//      into the TTY subsystem.
//
//    • If fp->tty is NULL, the STDIN stream is misconfigured.
//
//    • Permission enforcement (sync.can_write) happens earlier
//      in __write_imp() before reaching this block.
//
// ------------------------------------------------------------

    if (fp->_file == STDIN_FILENO)
    {
        if (fp->____object == ObjectTypeVirtualConsole)
        {
            if (fp->tty != NULL) 
            {
                //printk("0:: tty not null\n");
                nbytes = (ssize_t) __tty_write(fp->tty, ubuf, count);
                return (ssize_t) nbytes;
            }
            if (fp->tty == NULL){
                printk("0:: tty null\n");
                return (ssize_t) -1;
            }
        }
        if (fp->____object == ObjectTypeFile){
            goto RegularFile;
        }
        if (fp->____object == ObjectTypeTTY){
            goto tty_object;
        }
        goto fail;
    }

//
// ------------------------------------------------------------
//  WRITE TO STDOUT  (fd = 1)
// ------------------------------------------------------------
//
//  This block handles write() calls directed at STDOUT.
//
//  In Gramado, STDOUT is typically backed by a Virtual Console
//  (TTY). Writing to STDOUT means sending characters to the
//  console output subsystem.
//
//  Behavior:
//
//  1. If STDOUT is a Virtual Console (TTY):
//       - fp->tty must be non‑NULL.
//       - __tty_write2() copies the bytes into the TTY output queue.
//       - output_worker_number selects which output worker will flush.
//       - tty_flush_output_queue_ex() pushes the queued bytes to the
//         actual screen (foreground console).
//
//  2. If STDOUT is a regular file:
//       - Fall through to the RegularFile handler.
//
//  3. Any other object type is invalid for STDOUT writes.
//
//  Notes:
//
//    • This is the main path used by printf(), puts(), write(), and
//      all libc output functions.
//
//    • __tty_write2() handles buffering and queueing, while the flush
//      routine performs the actual rendering to the screen.
//
//    • If fp->tty is NULL, the STDOUT stream is misconfigured.
//
//    • Permission enforcement (sync.can_write) happens earlier in
//      __write_imp() before reaching this block.
//
// ------------------------------------------------------------

    if (fp->_file == STDOUT_FILENO)
    {
        if (fp->____object == ObjectTypeVirtualConsole)
        {
            if (fp->tty != NULL) 
            {
                //if (g_redirect_printk_to_serial_during_syscalls == TRUE){
                    //return (int) debug_print_nbytes( 
                        //(const void *) ubuf, 
                        //(size_t) count );
                //} else {
                    nbytes = (ssize_t) __tty_write2(fp->tty, ubuf, count);
                    fp->tty->output_worker_number = TTY_OUTPUT_WORKER_FGCONSOLE;
                    tty_flush_output_queue_ex(fp->tty);
                    return (ssize_t) nbytes;
                //}
            }
            if (fp->tty == NULL){
                //printk("1:: tty null\n");
                return (ssize_t) -1;
            }
        }
        if (fp->____object == ObjectTypeFile){
            goto RegularFile;
        }
        if (fp->____object == ObjectTypeTTY){
            goto tty_object;
        }
        goto fail;
    }

//
// ------------------------------------------------------------
//  WRITE TO STDERR  (fd = 2)
// ------------------------------------------------------------
//
//  This block handles write() calls directed at STDERR.
//
//  In Gramado, STDERR behaves almost exactly like STDOUT, except
//  that it is traditionally used for diagnostic or error output.
//  The kernel does not enforce any special formatting here, but
//  the path is kept separate for compatibility with POSIX and
//  libc expectations.
//
//  Behavior:
//
//  1. If STDERR is a Virtual Console (TTY):
//       - fp->tty must be non‑NULL.
//       - __tty_write2() queues the bytes into the TTY output buffer.
//       - output_worker_number selects the foreground console worker.
//       - tty_flush_output_queue_ex() pushes the queued bytes to the
//         actual screen immediately.
//
//     This ensures that error messages appear even if stdout is
//     redirected or buffered.
//
//  2. If STDERR is a regular file:
//       - Fall through to the RegularFile handler.
//
//  3. Any other object type is invalid for STDERR writes.
//
//  Notes:
//
//    • STDERR is typically unbuffered in user‑space libc, but the
//      kernel treats it the same as STDOUT at this level.
//
//    • If fp->tty is NULL, the STDERR stream is misconfigured.
//
//    • Permission enforcement (sync.can_write) happens earlier in
//      __write_imp() before reaching this block.
//
// ------------------------------------------------------------

    if (fp->_file == STDERR_FILENO)
    {
        if (fp->____object == ObjectTypeVirtualConsole)
        {
            if (fp->tty != NULL) 
            {
                //if (g_redirect_printk_to_serial_during_syscalls == TRUE){
                    //return (int) debug_print_nbytes( 
                        //(const void *) ubuf, 
                        //(size_t) count );
                //} else {
                    nbytes = (ssize_t) __tty_write2(fp->tty, ubuf, count);
                    fp->tty->output_worker_number = TTY_OUTPUT_WORKER_FGCONSOLE;
                    tty_flush_output_queue_ex(fp->tty);
                    return (ssize_t) nbytes;
                //}
            }
            if (fp->tty == NULL){
                //printk("2:: tty null\n");
                return (ssize_t) -1;
            }
        }
        if (fp->____object == ObjectTypeFile){
            goto RegularFile;
        }
        if (fp->____object == ObjectTypeTTY){
            goto tty_object;
        }
        goto fail;
    }

//
// == NIC device ===============================================
//

    if ( fp->____object == ObjectTypeNIC ){
       printk("__write_imp: Writing on NIC device ... #todo\n");
       //network_on_sending(ubuf,count);
       return 0;
   }

//
// == Sockets ===============================================
//
    ncopy = count;

// == Socket ===============================
// Descobrindo o soquete que devemos copiar.
// Se o arquivo é do tipo socket, então devemos
// saber onde está o buffer.
// #todo: Talvez podemos chamar a função socket_write().
// #todo: Lidar com a questao do copiar, pois
// accept deve retornar o fd do cliente, para que o servidor
// construa uma lista de clientes.
// Entao copiar sera uma opçao, gerenciada por uma flag.

// #bugbug
// Nao podemos fazer a copia se os dois sockets 
// estiverem com a conexao pendente.

    // Write into a socket file
    if (fp->____object == ObjectTypeSocket)
    {
        do_credits_by_tid(lapic_info[0].current_tid);

        // -- Below is for remote connections ------------
        // Check the socket validation and state
        // Send data to a REMOTE peer.
        // We get the connection information based on the client's socket.
        // Established AF_INET → real TCP send.
        // see: tcp.c
        // SEND: (Not writting into the file)
        struct socket_d *sk = fp->socket;
        if ((void*) sk != NULL)
        {
            if ( sk->magic == 1234 && 
                 sk->family == AF_INET && 
                 sk->state == SS_CONNECTED )
            {
                if (sk->is_client_connecting_with_remote_server == TRUE)
                {
                    int sent = (int) tcp_socket_send(sk, ubuf, count);
                    if (sent < 0){
                        // return (int) -1;
                    }
                    return (int) sent;
                }

                if (sk->is_remote_client_connecting_with_local_server == TRUE)
                {
                    int sent = (int) tcp_socket_send(sk, ubuf, count);
                    if (sent < 0){
                        // return (int) -1;
                    }
                    return (int) sent;
                }
            } 
        }

        // Fallback: 
        // Old local IPC behaviour for socket file.
        
        // -- Below is for local connections ------------

        // Can't write.
        if ((fp->_flags & __SWR) == 0){
            //debug_print("__write_imp: [FAIL] flag __SWR \n");
            //yield (lapic_info[0].current_tid);
            goto fail;
        }

        // cheio? 
        // Não podemos escrever porque o buffer está cheio.
        // Acorde os leitores para esvaziar.
        // Mas e se não tiver mais escritores.
        // #todo: Indicação da quantidade de escritores.
        // Sendo assim, vamos dizer que também podem ler
        // caso existam leitores. Mas não pode mais escrever.
        if (fp->socket_buffer_full == TRUE)
        {
            
            //debug_print("__write_imp: [FAIL] can't write on a full buffer\n");
            
            //#debug
            //debug_print("__write_imp: WAKEUP READER\n");
            
            fp->_flags = 0; // não pode mais escrever.
            fp->_flags |= __SRD;                 // pode ler.
            //do_thread_ready( fp->tid_waiting );  // acorda leitores
            //fp->tid_waiting = -1;
            if (fp->sync.block_on_write_full == TRUE)
            {
                //#debug
                //debug_print("__write_imp: SLEEP WRITER\n");
                //fp->tid_waiting = lapic_info[0].current_tid;
                //do_thread_waiting(lapic_info[0].current_tid);
                yield (lapic_info[0].current_tid);
                goto fail;
            }
            yield (lapic_info[0].current_tid); 
            goto fail;
        }

        // Se o buffer não estiver cheio,
        // Então escreva e acorde os leitores.
        if (fp->socket_buffer_full == FALSE)
        {
            // Se podemos escrever.
            // #todo: Ja fizemos isso logo acima.
            if (fp->_flags & __SWR)
            {
                //debug_print ("__write_imp: >>>> WRITE\n");
                fp->_flags = 0;

                // Write in the socket buffer.
                nbytes = 
                    (ssize_t) file_write_buffer ( 
                                  (file *) fp, 
                                  (char *) ubuf, 
                                  (int) count );

                // fail
                if (nbytes <= 0){
                    //debug_print("__write_imp: [FAIL] file_write_buffer couldn't write on socket \n");
                    //#todo: Isso pode afetar o desempenho.
                    yield (lapic_info[0].current_tid);
                    goto fail;
                }

                // ok, write funcionou.
                if (nbytes>0)
                {
                    // #debug
                    // debug_print("__write_imp: WAKEUP READER\n");
                    
                    fp->socket_buffer_full = TRUE;     // buffer cheio
                    fp->_flags &= ~__SWR;              // nao posso mais ESCREVER.            
                    fp->_flags |= __SRD;               // pode ler 
                    //do_thread_ready(fp->tid_waiting);  // acorda leitores
                    //fp->tid_waiting = -1;
                
                    // #bugbug
                    // Isso pode ser ruim pela natureza da chamada sys_write()
                    // que vem de uma syscall que nao salvou o contexto.
                    if (fp->sync.block_on_write == TRUE)
                    {
                        // #debug
                        //debug_print("__write_imp: SLEEP WRITER\n");
                        
                        //fp->tid_waiting = lapic_info[0].current_tid;
                        //do_thread_waiting(lapic_info[0].current_tid);
                    }
                    // #bugbug: test ...
                    // impedir que eu mesmo me leia.
                    //yield (lapic_info[0].current_tid);
                    return (ssize_t) nbytes;
                }
            }
        }

        panic("__write_imp: Unexpected error when writing on socket\n");
    }

//
// Arquivos normais (regular)
//

RegularFile:

// == Regular file =========================================
// Tem que retonar o tanto de bytes escritos.
// Escreve em uma stream uma certa quantidade de chars.

    if (fp->____object == ObjectTypeFile)
    {
        // Can't write.
        if ( (fp->_flags & __SWR) == 0){
            //debug_print("__write_imp: [FLAGS] Can't write!\n");
            return 0;
        }

        // Can write.
        if (fp->_flags & __SWR)
        {
            // Regular file.
            nbytes = 
                (ssize_t) file_write_buffer ( 
                              (file *) fp, 
                              (char *) ubuf, 
                              (int) count );

            // Avisa que o arquivo não está mais no modo escrita,
            // que agora pode ler.

            // Adiciona o bit que permite a leitura.
            // Assim o servidor pode ler o request.
            // #todo: wait on write.
            // #bugbug:
            // A questão é que se o cliente está esperando por resposta,
            // então ele lerá também.
            // Atualizamos a flag e acordamos quem esperava pelo evento.

            if (nbytes>0){
                fp->_flags = __SRD;
                fp->sync.can_read = TRUE;
                //do_thread_ready(fp->tid_waiting);
                return (ssize_t) nbytes;
            }

            // suspenso.
            // Não conseguimos escrever ... 
            // nada de errado, apenas esperaremos.
            //do_thread_waiting (lapic_info[0].current_tid);
            //fp->tid_waiting = lapic_info[0].current_tid;
            //fp->_flags |= __SWR;  //pode escrever.
            //scheduler();
            //debug_print ("__write_imp: [FAIL] file_write_buffer fail!\n");
            return 0;
        }
 
        //debug_print ("__write_imp: [FAIL] Something is wrong!\n");
        return (ssize_t) (-1);
    } //regular file.

// ======================================================
// Pseudo terminal multiplexer.
    if (fp->____object == ObjectTypePTMX){
        printk ("__write_imp: [TODO] trying to write a PTMX device file\n");
        return 0;
    }

// ======================================================
// PTY (pseudo terminal) write path
//
// FULL DUPLEX MODEL:
//
// 1) MASTER → SLAVE (terminal input → shell stdin)
//    - The master writes into the slave's *input queue*
//    - The slave will later read from its input queue
//
// 2) SLAVE → MASTER (shell output → terminal display)
//    - The slave writes into the master's *output queue*
//    - The master will later read from its output queue
//
// Subtypes:
//    TTY_SUBTYPE_PTY_MASTER  = PTY master endpoint
//    TTY_SUBTYPE_PTY_SLAVE   = PTY slave endpoint

tty_object:

    if (fp->____object == ObjectTypeTTY)
    {
        //printk ("__write_imp: [TODO] trying to write a PTY device file\n");
        if ((void*)fp->tty == NULL)
            return -1;

        // MASTER → SLAVE (write into slave input queue)
        if (fp->tty->subtype == TTY_SUBTYPE_PTY_MASTER)
        {
            if ((void*)fp->tty->link == NULL)
                return -1;
            return (ssize_t) __tty_write(fp->tty->link,ubuf,count);
        }
        // SLAVE → MASTER (write into master output queue)
        if (fp->tty->subtype == TTY_SUBTYPE_PTY_SLAVE)
        {
            if ((void*)fp->tty->link == NULL)
                return -1;
            return (ssize_t) __tty_write2( fp->tty->link, ubuf, count );
        }
        return 0;
    }

// ======================================================
// Virtual console (TTY). But NOT the standard streams.
    if (fp->____object == ObjectTypeVirtualConsole)
    {
        if (fd == STDIN_FILENO || 
            fd == STDOUT_FILENO || 
            fd == STDERR_FILENO )
        {
            return -1;
        }

        // Write into that console’s TTY output queue
        // Flush to screen (or background buffer)
        if (fp->tty != NULL)
        {
            ssize_t nbytes = __tty_write2(fp->tty, ubuf, count);
            fp->tty->output_worker_number = TTY_OUTPUT_WORKER_FGCONSOLE;
            tty_flush_output_queue_ex(fp->tty);
            return (ssize_t) nbytes;
        }
        return -EINVAL;
    }

// ======================================================
// File system
    if (fp->____object == ObjectTypeFileSystem){
        printk ("__write_imp: [TODO] trying to write a file system\n");
        return 0;
    }

// ======================================================
// pipe:
// See: pipe.c
    if (fp->____object == ObjectTypePipe)
    {
        // Using the same routine for regular files.
        return (ssize_t) file_write_buffer ( 
                              (file *) fp, 
                              (char *) ubuf, 
                              (int) count );
    }

    // ...

//==============================================
    debug_print ("__write_imp: [FAIL] Unknown object type\n");
//==============================================

fail:
    // #debug
    // debug_print ("__write_imp: [FAIL] Something is wrong!\n");
    // printk      ("__write_imp: [FAIL] something is wrong!\n");

// fail2:

    //invalidate_screen();

    // Não conseguimos escrever ... 
    // Estamos com problemas 
    //do_thread_waiting (lapic_info[0].current_tid);
    //fp->tid_waiting = lapic_info[0].current_tid;
    //fp->_flags |= __SWR;  //pode escrever.
    //scheduler();

    return (ssize_t) (-1);
}

// __open_imp:
// Here is the sys_open implementation.
// Syscall 16.
// #ps: open() is not related with fcntl.h?
// SVr4,  4.3BSD,  POSIX.1-2001. 
// Limits:
// Probably BUFSIZ (1024 for now) is the limit for this routine.
// To improve this we need to allocate a bigger buffer 
// in the file structure.
// The worker is: do_read_file_from_disk() with the same limit.
// Open a file, or create if is doesn't exist.
// creat chama open.
// open tenta ler num arquivo que nao existe?
// IN:
// pathname, flags, mode
// OUT: 
//   fd

int 
__open_imp (
    const char *pathname, 
    int flags, 
    mode_t mode )
{
    file *fp;
    struct te_d *p;  // Process structure
    pid_t current_process = -1;
    char pathname_local_copy[256];
//    int value = -1;

    //debug_print ("__open_imp: $\n");

// parameters:
    if ((void*) pathname == NULL){
        return (int) (-EFAULT);
    }
    if (*pathname == 0){
        return (int) (-EFAULT);
    }

// Process:
// Get PID for the current process for a given core.
// Get the process pointer.

    // IN: core id
    current_process = (pid_t) get_current_process(0);

    if (current_process < 0 || current_process >= PROCESS_COUNT_MAX)
    {
        debug_print("__open_imp: current_process\n");
        goto fail;
    }
    p = (void *) teList[current_process];
    if ((void *) p == NULL){
        debug_print("__open_imp: p\n");
        goto fail;
    }
    if (p->used != TRUE || p->magic != 1234){
        debug_print("__open_imp: p validation\n");
        goto fail;
    }

// pathname:
// Make a local copy of the pathname

    memset(pathname_local_copy, 0, 256);
    // #todo: Maybe we can use it as safe measure
    // size_t PathSize = strlen(pathname_local_copy);
    strncpy(pathname_local_copy, pathname, 256);
    pathname_local_copy[255-1] = 0;

// ----------------------------
// #hackhack
// Trying to open the current kernel virtual console.
// But this is the standard stdout for everyone.
// Wrinting on stdout always send the data to the current console.

// /dev/tty	
//    Represents the controlling terminal for the current process. 
//    If a process is attached to a terminal, reading from /dev/tty gets its input, 
//    and writing sends output there.

    // # All the processes are associated with the current kernel console
    //   in the open file table.
    if (gramado_strncmp(pathname_local_copy, "/dev/tty", 8) == 0)
        return (int) STDOUT_FILENO;
    if (gramado_strncmp(pathname_local_copy, "/DEV/TTY", 8) == 0)
        return (int) STDOUT_FILENO;

// /dev/console	
//     Represents the system console, where kernel messages 
//     (printk()) and emergency output are directed. 
//     This is often mapped to the first virtual terminal (/dev/tty0) or 
//     a serial device in headless setups.

    if (gramado_strncmp(pathname_local_copy, "/dev/console", 12) == 0)
        return (int) STDOUT_FILENO;
    if (gramado_strncmp(pathname_local_copy, "/DEV/CONSOLE", 12) == 0)
        return (int) STDOUT_FILENO;

//----------------------------

// Searth for a device associated with this path
// in the deviceList[]
// See: devmgr.c

// #test #todo
// OK, it's working when we call open() from ring3,
// using a pathname.
// Now we need to get the filepointer 
// from the device data structures,
// put it into the process structure in p->Objects[]
// and return the index to the ring3.

    fp = (file *) devmgr_search_in_dev_list(pathname_local_copy);

// Yes, 
// we have a valid pointer found in the table.

    int dev_fd = -1;
    int SlotIterator = 0;

    if ((void*) fp != NULL)
    {
        if (fp->isDevice == TRUE)
        {
            // #todo 
            // Put it into the list inside the
            // current process structure
            // and return the fd.
            printk("__open_imp: #todo isDevice\n");

            // Find a free file descriptor slot
            for (SlotIterator = 0; SlotIterator < OPEN_MAX; SlotIterator++)
            {
                if (p->Objects[SlotIterator] == 0)
                {
                    dev_fd = SlotIterator;
                    break;
                }
            }
            if (dev_fd < 0)
                return -EMFILE;  // No free descriptors

            // Install the file pointer into the process table
            fp->_file = (int) dev_fd;
            p->Objects[dev_fd] = (unsigned long) fp;

            // Optional: track usage
            fp->fd_counter++;

            printk("__open_imp: device opened, fd=%d fd=%d\n", 
                dev_fd, fp->_file );
            if (fp->____object == ObjectTypeTTY){
                printk("____object: ObjectTypeTTY\n");
            }
            if (fp->____object == ObjectTypeVirtualConsole){
                printk("____object: ObjectTypeVirtualConsole\n");
            }
            return (int) dev_fd;
        }
    }

// Vamos carregar o arquivo que esta no disco.
// See: fs.c
// OUT: fd

// #bugbug
// This function is gonna call fs_fntos()
// that is gonna include the extension .bin
// if the name doesn't have one.
// This is not what we want for all the cases.

    fp = (file *) do_read_file_from_disk ( 
                (char *) pathname_local_copy, 
                flags, 
                mode );

    if ((void*)fp == NULL)
        return (int) -1;
    if (fp->used != TRUE)
        return (int) -1;
    if (fp->magic != 1234)
        return (int) -1;
    int fd = fp->_file;  // File Descriptor
    if (fd < 0)
        return (int) -1;
    if (fd > 31)
        return (int) -1;

    return (int) fd;

fail:
    return (int) -1;
}

// __close_imp:
// It implements the service for close() syscall.
// Fechar um dos objetos abertos do processo atual.
// O descritor é um índice na sua tabela de objetos abertos.
// #todo: Se fecharmos um socket, tem que antes destruir a estrutura
// de socket associada ao arquivo.
// See:
// https://man7.org/linux/man-pages/man2/close.2.html
// https://pubs.opengroup.org/onlinepubs/009695399/functions/close.html
/*
A successful close does not guarantee that the data has been
successfully saved to disk, as the kernel uses the buffer cache
to defer writes.  Typically, filesystems do not flush buffers
when a file is closed.  If you need to be sure that the data is
physically stored on the underlying disk, use fsync(2).  (It will
depend on the disk hardware at this point.)
*/

// #: It needs to be used only as a worker for syscalls.
int __close_imp(int fd)
{
    file *fp;  // Object: file pointer
    struct te_d *p;
    pid_t current_process = -1;
    int Done=FALSE;

// Invalid fd
    if (fd < 0 || fd >= OPEN_MAX)
    {
        debug_print("__close_imp: fd\n");
        return (int) (-EBADF);
    }

// Invalid fd
// Can't close standard streams
    if (fd == 0)
        return (int) (-EBADF);
    if (fd == 1)
        return (int) (-EBADF);
    if (fd == 2)
        return (int) (-EBADF);

// Process
// Get PID for the current process for a given core.
// IN: core id
    current_process = (pid_t) get_current_process(0);
    if (current_process < 0 || current_process >= PROCESS_COUNT_MAX)
    {
        debug_print("__close_imp: current_process\n");
        goto fail;
    }
    p = (void *) teList[current_process];
    if ((void *) p == NULL){
        debug_print("__close_imp: p\n");
        goto fail;
    }
    if (p->used != TRUE || p->magic != 1234){
        debug_print("__close_imp: p validation\n");
        goto fail;
    }

// The object is a file structure
    fp = (file *) p->Objects[fd];
    if ((void *) fp == NULL){
        debug_print("__close_imp: fp\n");
        goto fail;
    }
    if (fp->used != TRUE || fp->magic != 1234){
        debug_print("__close_imp: fp validation\n");
        goto fail;
    }

// What type of object?
// socket, pipe, virtual console, tty, regular file ??

    Done = FALSE;

// ===============================================
// socket
// Do NOT save it into the disk
    if (fp->____object == ObjectTypeSocket)
    {
        debug_print("__close_imp: Trying to close a socket object\n");

        struct socket_d *sk = fp->socket;
        if ((void*)sk == NULL){
            goto fail;
        }
        socket_close(sk);
        // Done = TRUE;
        return 0;
    }

// ==============================================
// pipe
// #todo
    if (fp->____object == ObjectTypePipe){
        debug_print("__close_imp: Trying to close a pipe object\n");
        Done = TRUE;
    }

// ====================================================
// virtual console
// #todo
    if (fp->____object == ObjectTypeVirtualConsole){
        debug_print("__close_imp: Trying to close a virtual console object\n");
        return 0;
    }

// =====================================================
// tty
// #todo
    if (fp->____object == ObjectTypeTTY){
        debug_print("__close_imp: Trying to close a tty object\n");
        Done = TRUE;
    }

// #bugbug
// Poderemos ter problemas aqui com os diversos tipos
// de arquivos.

// #bugbug
// ugly test

// ===========================================
// regular file
// Save the file if it is a regular file.
// #todo: This is a good time to handle 
// the reference counter.

    if (fp->____object == ObjectTypeFile)
    {
        debug_print("__close_imp: [FIXME] trying to close a regular file\n");
        //debug_print("__close_imp: [FIXME] fat16SaveFile\n");

        // #fixme: buffer limit
        if (fp->_lbfsize < 512){  
            debug_print("__close_imp: [FIXME] Ajusting file size\n");
            fp->_lbfsize = 512; 
        }

        // Save file in the root dir.
        // #bugbug: Where to save?
        debug_print("__close_imp: [FIXME] fat16SaveFile\n");

        fat16SaveFile ( 
            VOLUME1_FAT_ADDRESS, 
            VOLUME1_ROOTDIR_ADDRESS, 
            FAT16_ROOT_ENTRIES,
            (char *)         fp->_tmpfname, 
            (unsigned long) (fp->_lbfsize/512),  // File size in sectors       
            (unsigned long)  fp->_lbfsize,       // File size in bytes  
            (char *)         fp->_base,          // buffer address          
            (char)           0x20 );             // flags

        Done = TRUE;
    }

    // ...

// Object type not supported
    if (Done != TRUE){
        debug_print("__close_imp:[FAIL] Object type not supported\n");
        goto fail;
    }

// Close it!
// Everything was done.
// Let's destroy the object pointer, 
// empty the spot in the list and return 0.
// + Clear local pointer
// + clear FD slot in process table
// + return 0 (OK)
    if (Done == TRUE)
    {
        fp = NULL;
        p->Objects[fd] = (unsigned long) 0;
        return 0;
    }

fail:
    debug_print("__close_imp: [FAIL]\n");
    return (int) (-1);
}

// get_file_from_fd:
// helper
// dado o fd, pegamos o ponteiro 
// para estrutura de arquivo na lista de
// objetos abertos no processo atual.
// ## Talvez essa rotina ja foi implementada
// em algum outro lugar.
// Prototype in rtl/sci/sys.h
// OUT:
// Return the file pointer.

file *get_file_from_fd(int fd)
{
    file *fp;
// Current process
    struct te_d *p;
    pid_t current_pid = -1;

// Parameter
    if (fd < 0 || fd >= 32){
        goto fail;
    }

// Current PID and process pointer
// Get PID for the current process for a given core.
// IN: core id

    current_pid = (pid_t) get_current_process(0);
    if ( current_pid < 0 || current_pid >= PROCESS_COUNT_MAX )
    {
        return NULL;
    }
    p = (struct te_d *) teList[current_pid];
    if ((void*) p == NULL){
        debug_print ("get_file_from_fd: p\n");
        panic       ("get_file_from_fd: p\n");
        //return NULL;
    }
    if (p->used != TRUE){
        return NULL;
    }
    if (p->magic != 1234){
        return NULL;
    }

// File pointer
    fp = (file *) p->Objects[fd];
    if ((void*) fp == NULL){
        //#debug
        //printk("fd{%d} pid{%d}\n",fd,current_pid);
        //printk("entry0: %x\n", p->Objects[0]);
        //printk("entry1: %x\n", p->Objects[1]);
        //printk("entry2: %x\n", p->Objects[2]);
        //printk("entry3: %x\n", p->Objects[3]);
        //printk("entry4: %x\n", p->Objects[4]);
        goto fail;
    }
    return (file *) fp;

fail:
    return NULL;
}

// Get free slots in the file_table[].
// Called by kstdio.c when creating streams.
int get_free_slots_in_the_file_table(void)
{
    file *tmp;
    register int i=0;

    if (FileTableInfo.initialized != TRUE){
        panic("get_free_slots_in_the_file_table: FileTableInfo not initialized\n");
    }

    // Get a free slot in the file_table[]
    // #ps: reference counter is 0.
    for (i=0; i<NUMBER_OF_FILES; i++)
    {
        tmp = (void*) file_table[i];
        if (tmp->used == TRUE && 
            tmp->magic == 1234 && 
            tmp->fd_counter == 0)
        { 
            return (int) i;
        }
    };

    return (int) -1;
}

// Get free slots in the inode_table[].
int get_free_slots_in_the_inode_table(void)
{
    struct inode_d *tmp;
    register int i=0;

    // Get a free slot in the inode_table[]
    // #ps: reference counter is 0.
    for (i=0; i<32; i++)
    {
        tmp = (void*) inode_table[i];
        if (tmp->used == TRUE && 
            tmp->magic == 1234 && 
            tmp->filestruct_counter == 0)
        { 
            return (int) i; 
        }
    }

    return (int) -1;
}

// Get file system type.
// #bugbug: 
// What is the volume?
// Is it only for the system volume?
int get_filesystem_type (void)
{
    return (int) g_currentvolume_filesystem_type;
}

// Set file system type.
// #bugbug: 
// What is the volume?
// Is it only for the system volume?
void set_filesystem_type (int type)
{
    if (type < 0)
        return;
    g_currentvolume_filesystem_type = (int) type;
}

// fs_count_path_levels:
// Counting path levels.
// Credits: Sirius OS.
// return 'int'?
unsigned long fs_count_path_levels(unsigned char *path)
{
    unsigned long Counter=0;
    register int i=0;
// (80*25), 25 lines.
    size_t MaxChars = 2000;

// Parameter
    if ((void*) path == NULL){
        return 0;
    }
    if (*path == 0){
        return 0;
    }

    for (i=0; i < MaxChars; i++)
    {
        if (path[i] == '/')
        {
            Counter++;
        }
        if (path[i] == '\0')
        {
            break;
        }
    };

    return (unsigned long) Counter;
}

// Get a file pointer from the global file table.
void *get_file (int Index)
{
//Limits.
//#todo: max.
    if (Index < 0){
        // ?? todo: message
        return NULL;
    }
    return (void *) file_table[Index];
}

// Set a file pointer into the global file table.
void set_file(void *file, int Index)
{
// #todo:
// Limite máximo da lista.

// Parameters
    if ((void *) file == NULL){
        // ?? todo: message
        return;
    }
    if (Index < 0){
        // ?? todo: message
        return;
    }

// Include pointer into the list
    file_table[Index] = (unsigned long) file;
}

// #todo
// Change the return type to 'int' and
// remove all the messages. Maybe.
// Create the 'root' filesystem structure.
void fs_init_structures (void)
{
    int Type=0;

    //debug_print ("fs_init_structures: [TODO]\n");

//
// root
//

// struct
// Create the 'root' filesystem structure.
// Initialize the 'root' filesystem structure.
// "/"

    //debug_print ("fs_init_structures: root\n");

    root = (void *) kmalloc( sizeof(struct filesystem_d) );
    if ((void *) root == NULL){
        panic("fs_init_structures: Couldn't create the root structure\n");
    }
    memset( root, 0, sizeof(struct filesystem_d) );
    // kobject
    root->kobj._type = ObjectTypeFileSystem;
    root->kobj._class = ObjectClassKernelObject;
    root->used = TRUE;
    root->magic = 1234;
    root->name = (char *) ____root_name;

// #todo 
// #bugbug   volume_vfs  ??

// Se o volume do vfs ainda não foi criado 
// então não podemos prosseguir.

    //if ( (void *) volume_vfs == NULL )
    //{
    //    debug_print("fs_init_structures: [FAIL] volume_vfs not initialized");
    //    panic      ("fs_init_structures: [FAIL] volume_vfs not initialized");
    //}
    //volume_vfs->fs = root;

// Save is in the 'storage' low level structure.

    if ((void*) storage == NULL){
        panic("fs_init_structures: storage");
    }
    storage->fs = (void*) root;
    // ...

// Type
// #bugbug: 
// Em qual disco e volume pegamos o tipo de sistema de arquivos?

    //debug_print ("fs_init_structures: Type\n");

// #bugbug
// Why do we have this information?
    Type = (int) get_filesystem_type();
    Type = (Type & 0xFFFF);
    if (Type <= 0){
        panic ("fs_init_structures: [PANIC] Type\n");
    } else {
        root->type = (int) Type;
    };

    switch (Type){

    case FS_TYPE_FAT16:

        // Disk stuff.
        // spc - Sectors per cluster.
        root->spc = (int) VOLUME1_SPC;
        //root->spc = (int) get_spc(); 

        // Rootdir, Fat and data area.
        // #bugbug: Specific for fat16.
        
        // root dir
        root->rootdir_address = VOLUME1_ROOTDIR_ADDRESS;
        root->rootdir_first_lba = VOLUME1_ROOTDIR_LBA;
        //root->rootdir_last_lba = 0;  //#todo 
        root->rootdir_size_in_sectors = 0;  //#todo

        // fat1
        root->fat_address = VOLUME1_FAT_ADDRESS;
        root->fat_first_lba = VOLUME1_FAT_LBA;
        //root->fat_last_lba = 0;  //#todo
        root->fat_size_in_sectors = 0;  //#todo

        // fat2
        // ...

        // dataarea
        //filesystem->dataarea_address = ??;
        root->dataarea_first_lba = VOLUME1_DATAAREA_LBA; 
        //root->dataarea_last_lba = 0;  //#todo
        //root->dataarea_size_in_sectors = 0;  //#todo
 
        //root->fs_first_lba = 0;  //#todo
        
        //#todo (dataarea + dataarea size)?
        //root->fs_last_lba = 0;   

        //(mbrsize + reserved + rootdirsize + fat1size + fat2size +dataareasize)
        //root->fs_size_in_sectors = 0;

        // Root dir.

        // Number of entries in the root dir.
        // #bugbug: Specific for fat16.
        root->dir_entries = FAT16_ROOT_ENTRIES;

        // Size of the entry in bytes.
        // #bugbug: Specific for fat16.
        root->entry_size = FAT16_ENTRY_SIZE;

        // ...
        break;

    // #todo: Not implemented yet.
    case FS_TYPE_EXT2:
    default:
        panic ("fs_init_structures: Default Type\n");
        break;
    };
}

// Close a file given the structure pointer
int file_close(file *_file)
{
// #todo: Not implemented yet!

    debug_print("file_close: todo\n");

// Structure validation
    if ((void*) _file == NULL){
        return (int) -1;
    }
    if (_file->used != TRUE)
        return (int) -1;
    // Reuse support
    //if (_file->magic == 4321)
        //something();

    // ...

    return (int) -1;
}

size_t file_get_len(file *_file)
{
// Not implemented yet!

    debug_print("file_get_len: todo\n");

    if ((void*) _file == NULL){
        return -1;
    }

    //... 

    return (size_t) -1;
}

//OUT: inode structure.
struct inode_d *file_inode (file *f)
{
    if ((void *) f == NULL){
        return NULL;
    }
    // #todo: Test MAGIC.
    return (struct inode_d *) f->inode;
}

// ??
// #todo: Explain this.
int file_truncate (file *_file, size_t len)
{
// Not implemented yet!

    debug_print("file_truncate: todo\n");

    if ( (void*) _file == NULL ){
        return -1;
    }
    if (len<0){
        return -1;
    }

    return -1;
}

// fsCheckELFFile:
// Check the signature in a elf header.
// OUT:
// 0 = OK. #todo: Isso poderia ser '1'.
// < 0 Means error.
// #todo
// We can do the same for some other types.
// Use TRUE or FALSE.

// #todo
// is address virtual or physical?
// Change this name to pa or va.

int fsCheckELFFile(unsigned long address)
{
    if (address == 0){
        return 0;
    }
    return (int) elfCheckSignature(address);
}

/*
 * fsInitTargetDir:
 *     Para inicializarmos o sistema já com um alvo.
 */
// #todo
// is dir_address virtual or physical?
// Change this name to dir_pa or dir_va.

// using the structure 'current_target_dir'.
// IN:
// directory address, directory name.

int fsInitTargetDir (unsigned long dir_address, char *dir_name)
{
    register int i=0;

    current_target_dir.used = TRUE;
    current_target_dir.magic = 1234;
    for ( i=0; i<11; i++ ){
        current_target_dir.name[i] = '\0';
    };

// Dir address
    if (dir_address == 0){
        panic("fsInitTargetDir: dir_address\n");
    }
    //current_target_dir.current_dir_address = VOLUME1_ROOTDIR_ADDRESS;
    current_target_dir.current_dir_address = 
        (unsigned long) dir_address;

// Dir name
    if ((void*) dir_name == NULL){
        panic("fsInitTargetDir: dir_name\n");
    }
    if (*dir_name == 0){
        panic("fsInitTargetDir: *dir_name\n");
    }
    //current_target_dir.name[0] = '/';
    //current_target_dir.name[1] = 0;

// Limits: 
// Copy 8 bytes only
    for ( i=0; i<8; i++ ){
        current_target_dir.name[i] = dir_name[i];
    };

    current_target_dir.initialized = TRUE;
    return 0;
}

// fsList
// Ring 0 routine to list files.
// #todo
// Use 'pathname'.
// #shortcut: '[' 

int fsList(const char *dir_name)
{
    int Absolute = FALSE;
    register int i=0;

// Directory name
    if ((void *) dir_name == NULL){
        debug_print ("fsList: dir_name\n");
        goto fail;
    }
    if ( *dir_name == 0 ){
        debug_print ("fsList: *dir_name\n");
        goto fail;
    }

// Copy name
// Limits: 
// Copy 8 bytes only

    for (i=0; i<8; i++){
        current_target_dir.name[i] = dir_name[i];
    };
    current_target_dir.name[i] = '\0';

// The root directory.
// #shortcut: '[' 
// #todo: Explain it.
// Open the dirname '/'.

// --------------------------------------
// Default in root:

    current_target_dir.current_dir_address = VOLUME1_ROOTDIR_ADDRESS;
    current_target_dir.name[0] = '/';
    current_target_dir.name[1] = '\0'; 

// --------------------------------------
// [

    if ( dir_name[0] == '[' && 
         dir_name[1] == 0 )
    {
        //debug_print ("fsList: root\n");
        Absolute = TRUE;

        current_target_dir.current_dir_address = 
            VOLUME1_ROOTDIR_ADDRESS;
        
        // Clear the whole buffer
        for ( i=0; i<11; i++ ){
            current_target_dir.name[i] = '\0';
        };
        // Create the name.
        current_target_dir.name[0] = '/';
        current_target_dir.name[1] = '\0'; 
    }

// #bugbug
// We are using the current directory address,
// not the directory provide by the user.
// #todo
// Set up the current dir address, based on the
// name provided by the user.

//
// == current_target_dir ====================
//

// directory address.
    if (current_target_dir.current_dir_address == 0){
        debug_print ("fsList: current_target_dir.current_dir_address\n");
        goto fail;
    }
    
    // #bugbug
    // Missing string finalization.
    //printk ("fsList: current_target_dir.name = {%s}\n", current_target_dir.name);

// Listing ...
// IN:
// name, dir address, number of entries;
// No return value.

    // Well, the root dir has 512 entries.
    int n=256;
    if (current_target_dir.current_dir_address == VOLUME1_ROOTDIR_ADDRESS)
    {
        n = 512;
    }

    fsFAT16ListFiles ( 
        (const char *)     current_target_dir.name,
        (unsigned short *) current_target_dir.current_dir_address, 
        (int) n );

    return 0;

fail:
    debug_print ("fsList: fail\n");
    return (int) -1;
}

// fsListFiles:
// List files in a directory given the disk, volume and directory indices.
// #bugbug
// #todo: 
// Do not list this in ring0 but it has been useful for
// our ring 0 embedded shell.

void 
fsListFiles ( 
    int disk_id, 
    int volume_id, 
    int directory_id )
{
// #todo: Incomplete routine.

    // #todo: 
    // Checar mais limites.
    // Use this: if ( disk_id < 0 || volume_id < 0 || directory_id < 0 )

    if ( disk_id == -1 || 
         volume_id == -1 || 
         directory_id == -1 )
    {
        debug_print ("fsListFiles: [FAIL] parameters\n");
        goto fail;
    }

    printk ("fsListFiles: disk={%d} vol={%d} dir={%d}\n", 
        disk_id, volume_id, directory_id );

// Show it:
// Root dir for VFS.

    if ( current_disk == 0 && 
         current_volume == 0 && 
         current_directory == 0 )
    {
        debug_print ("fsListFiles: [FIXME] current\n");
        //vfsListFiles ();
        goto done;
    }

// #todo: 
// Suportar outros diretórios.
// ...

    goto done;

fail:
    printk ("fail\n");
done:
    return;
}

// fsUpdateWorkingDiretoryString:
// + Update the pathname in the current process structure.
// + Update the pathname in the global string.
// Used by the service 175, cd command.

void fsUpdateWorkingDiretoryString(char *string)
{
    struct te_d  *p;
    pid_t current_process = -1;
    char *tmp;
    register int i=0; 
    int string_size = 0;

    //debug_print ("fsUpdateWorkingDiretoryString:\n"); 

// Initialized?
    if (CWD.initialized != TRUE)
    {
        debug_print ("fsUpdateWorkingDiretoryString: [FAIL] CWD not initialized\n"); 
        // #todo
        // Call the initialization routine.
        return;
    }

// Parameter
    if ((void *) string == NULL){
        debug_print ("fsUpdateWorkingDiretoryString: string\n"); 
        return;  
    }
    if (*string == 0){
        debug_print ("fsUpdateWorkingDiretoryString: *string\n"); 
        return;  
    }
    tmp = string;

// String size.
    string_size = sizeof(string);
    if (string_size <= 0){
        debug_print ("fsUpdateWorkingDiretoryString: string_size\n"); 
        return;  
    }

// Current process
// Get PID for the current process for a given core.
// IN: core id

    current_process = (pid_t) get_current_process(0);
    if (current_process < 0 || current_process >= PROCESS_COUNT_MAX)
    {
        panic ("fsUpdateWorkingDiretoryString: current_process\n");
    }
    p = (struct te_d *) teList[current_process];
    if ((void *) p == NULL){
        panic ("fsUpdateWorkingDiretoryString: p\n");
    }
    if (p->used != TRUE || p->magic != 1234)
    {
        panic ("fsUpdateWorkingDiretoryString: p validation\n");
    }

// Atualiza a string do processo atual. 
// Concatenando.

    if ((void *) string != NULL)
    {
        // #bugbug
        // We need to handle the string size limit.

        // Concatenate string and separator.
        strcat(p->cwd_string, string);
        strcat(p->cwd_string, FS_PATHNAME_SEPARATOR);

        // Atualiza a string global usando a string do 
        // processo atual.
        // #bugbug: nao precisamos disso ...
        // so precismos de cwd na estrutura de processo.
            
        // #importante
        // Respeitar o limite.

        for (i=0; i<32; i++){
            CWD.path[i] = p->cwd_string[i];
        };
        CWD.path[31] = 0;  // finalize

        // #bugbug: rever isso.
        // Nome do diretório alvo atual.
            
        // nao precismos disso ...
        // ou usamos o cwd do processo ou
        // o diretorio raiz para paths absolutos.
            
        for (i=0; i< 11; i++)
        {
            current_target_dir.name[i] = *tmp;
            tmp++;
        };
        current_target_dir.name[11] = 0;  // finalize
    }
}

/*
 * fs_fntos:  
 *     (Filename to string).   
 *     'file name to string'.
 *     rotina interna de support.
 *     isso deve ir para bibliotecas depois.
 *     não tem protótipo ainda.
 * Created by: Luiz Felipe.
 * 2020 - Adapted by Fred Nora.
 */
 // #bugbug
 // Isso modifica a string lá em ring3.
 // prejudicando uma segunda chamada com a mesma string
 // pois já virá formatada.
// #bugbug
// const char * tornaria esse endereço em apenas leitura.
// Allowed in fat16: $ % ' - _ @ ~ ` ! ( ) { } ^ # &

void fs_fntos(char *name)
{
    int i=0;
    int ns = 0;
    char ext[4];
    //int WeReallyNeedAnBinExt = add_bin_ext;

    // #todo
    int fAddNewExt = FALSE;
    
// No extension
    ext[0] = 0;
    ext[1] = 0;
    ext[2] = 0;
    ext[3] = 0;

// Parameter
    if ((void*) name == NULL){
        return;
    }
    if (*name == 0){
        return;
    }

// Transforma em maiúscula enquanto não achar um ponto.
// #bugbug: 
// E se a string já vier maiúscula teremos problemas.

// Transforma somente as letras e 
// somente ate encontrarmos o ponto.
    //int max = (8+1+3); 
    //int max = (8); 
    while ( *name && *name != '.' )
    {
        // Se a string eh muito grande.
        //if (ns >= max)
            //break;
        
        if ( *name >= 'a' && *name <= 'z' )
        {
            *name -= 0x20;
        }
        name++;
        ns++;
    };

// #bugbug
// Esse negócio de acrescentar a extensão
// não é bom para todos os casos.
// >> name[0] significa que na ultima posiçao do ponteiro *p,
//    encontramos o valor 0x00.
// >> Mas ainda somos menor ou igual a 8, que eh o campo
//    para nome de 8 bytes.

    if ( name[0] == '\0' && ns <= 8 )
    {
        // The flag says that 
        // we're gonna have a new extension.
        fAddNewExt = TRUE;
        // Complete the DOS name with spaces. Until 8 bytes.
        goto CompleteName8WithSpaces;
    }

    //if ( name[0] == '.' && ns < 8 )

// Aqui name[0] é o ponto. 
// Mas o nome tem 8 bytes.
// Então constrói a extensão colocando as letras na extensão.

    for ( i=0; 
          i<3 && name[i+1]; 
          i++ )
    {
        // #ps: name[0] = '.'

        //Transforma uma letra da extensão em maiúscula.

        // Letras na extensao: 
        // Mudando as letras para maiusculo.
        if ( name[i+1] >= 'a' && 
             name[i+1] <= 'z' )
        {
            name[i+1] -= 0x20;   // Change
            ext[i] = name[i+1];  // Save
        }

        // Bytes especiais na extensao: 
        // Colocando os bytes, sem mudar.
        // Allowed in fat16: $ % ' - _ @ ~ ` ! ( ) { } ^ # &
                
        if ( name[i+1] == '$' ||
             name[i+1] == '%' ||
             name[i+1] == '-' ||
             name[i+1] == '_' ||
             name[i+1] == '(' ||
             name[i+1] == ')' ||
             name[i+1] == '{' ||
             name[i+1] == '}'  )
        {
            ext[i] = name[i+1];  // Save
        }

        // Se a extensao tiver numeros.
        if  ( name[i+1] >= '0' &&
              name[i+1] <= '9' ) 
        {
            ext[i] = name[i+1];  // Save
        }
        
        // E se tiver um 0x00 entre os bytes da extensao?
        // Mas a extensao tinha um ponto.
        if ( name[i+1] == 0x00 )
        {
            fAddNewExt = FALSE;
            goto CompleteName8WithSpaces;
        }
    };

// Acrescentamos ' ' até completarmos as oito letras do nome.
// Acrescentamos a extensão
// Finalizamos.

CompleteName8WithSpaces:

// Save some spaces in the name until 8 bytes.
    while (ns < 8)
    {
        *name++ = ' ';
        ns++;
    };

// Add extension
// AddExt:

// Prepare a new extension 
// if no extension was provided.
    if (fAddNewExt == TRUE)
    {
        // Pre-load the new extension bytes.
        ext[0] = 'B';  
        ext[1] = 'I';  
        ext[2] = 'N';  
        ext[3] = '\0';
    }

// Save extension bytes.
    for (i=0; i<3; i++)
    {
        // No caso de extensoes com 3 bytes
        // copiamos todos os bytes.
        if ( ext[i] != 0x00 )
        {
            *name++ = ext[i];  
        }
        
        // No caso das extensoes com menos bytes,
        // o buffer pode ter 0x00.
        // No lugar no 0x00 colocaremos ' '.
        if ( ext[i] == 0x00 )
        {
            *name++ = ' ';  
        }
    };

// #bugbug
// Is it an overflow?

    *name = '\0';
}

// No 'BIN' extension is added.
// Add '3 spaces' in the extension field.
void fs_fntos2(char *name)
{
    int i=0;
    int ns = 0;
    char ext[4];
    //int WeReallyNeedAnBinExt = add_bin_ext;

    // #todo
    int fAddNewExt = FALSE;
    
// No extension
    ext[0] = 0;
    ext[1] = 0;
    ext[2] = 0;
    ext[3] = 0;

// Invalid parameter
    if ((void*) name == NULL){
        return;
    }
    if (*name == 0){
        return;
    }

// Transforma em maiúscula enquanto não achar um ponto.
// #bugbug: 
// E se a string já vier maiúscula teremos problemas.

// Transforma somente as letras e 
// somente ate encontrarmos o ponto.
    //int max = (8+1+3); 
    //int max = (8); 
    while ( *name && *name != '.' )
    {
        // Se a string eh muito grande.
        //if (ns >= max)
            //break;
        
        if ( *name >= 'a' && *name <= 'z' )
        {
            *name -= 0x20;
        }
        name++;
        ns++;
    };

// #bugbug
// Esse negócio de acrescentar a extensão
// não é bom para todos os casos.
// >> name[0] significa que na ultima posiçao do ponteiro *p,
//    encontramos o valor 0x00.
// >> Mas ainda somos menor ou igual a 8, que eh o campo
//    para nome de 8 bytes.

    if ( name[0] == '\0' && ns <= 8 )
    {
        // The flag says that 
        // we're gonna have a new extension.
        fAddNewExt = TRUE;
        // Complete the DOS name with spaces. Until 8 bytes.
        goto CompleteName8WithSpaces;
    }

    //if ( name[0] == '.' && ns < 8 )

// Aqui name[0] é o ponto. 
// Mas o nome tem 8 bytes.
// Então constrói a extensão colocando as letras na extensão.

    for ( i=0; 
          i<3 && name[i+1]; 
          i++ )
    {
        // #ps: name[0] = '.'

        //Transforma uma letra da extensão em maiúscula.

        // Letras na extensao: 
        // Mudando as letras para maiusculo.
        if ( name[i+1] >= 'a' && 
             name[i+1] <= 'z' )
        {
            name[i+1] -= 0x20;   // Change
            ext[i] = name[i+1];  // Save
        }

        // Bytes especiais na extensao: 
        // Colocando os bytes, sem mudar.
        // Allowed in fat16: $ % ' - _ @ ~ ` ! ( ) { } ^ # &
                
        if ( name[i+1] == '$' ||
             name[i+1] == '%' ||
             name[i+1] == '-' ||
             name[i+1] == '_' ||
             name[i+1] == '(' ||
             name[i+1] == ')' ||
             name[i+1] == '{' ||
             name[i+1] == '}'  )
        {
            ext[i] = name[i+1];  // Save
        }

        // Se a extensao tiver numeros.
        if  ( name[i+1] >= '0' &&
              name[i+1] <= '9' ) 
        {
            ext[i] = name[i+1];  // Save
        }
        
        // E se tiver um 0x00 entre os bytes da extensao?
        // Mas a extensao tinha um ponto.
        if ( name[i+1] == 0x00 )
        {
            fAddNewExt = FALSE;
            goto CompleteName8WithSpaces;
        }
    };

// Acrescentamos ' ' até completarmos as oito letras do nome.
// Acrescentamos a extensão
// Finalizamos.

CompleteName8WithSpaces:

// Save some spaces in the name until 8 bytes.
    while (ns < 8)
    {
        *name++ = ' ';
        ns++;
    };

// Add extension
// AddExt:

// Prepare a new extension 
// if no extension was provided.
    if (fAddNewExt == TRUE)
    {
        // Pre-load the new extension bytes.
        // #warning:
        // fs_fntos2() do NOT add the .bin extension.
        ext[0] = ' ';  
        ext[1] = ' ';  
        ext[2] = ' ';  
        ext[3] = '\0';
    }

// Save extension bytes.
    for (i=0; i<3; i++)
    {
        // No caso de extensoes com 3 bytes
        // copiamos todos os bytes.
        if ( ext[i] != 0x00 )
        {
            *name++ = ext[i];  
        }
        
        // No caso das extensoes com menos bytes,
        // o buffer pode ter 0x00.
        // No lugar no 0x00 colocaremos ' '.
        if ( ext[i] == 0x00 )
        {
            *name++ = ' ';  
        }
    };

// #bugbug
// Is it an overflow?

    *name = '\0';
}

int fs_duplicate_fd(int oldfd, int start) 
{
    file *fp;
    int newfd = -1;
    struct te_d *p;
    pid_t current_process = get_current_process(0);

    if (oldfd < 0 || oldfd >= OPEN_MAX)
        return -EBADF;
    if (start < 0 || start >= OPEN_MAX)
        return -EINVAL;

// process
    p = (struct te_d *) teList[current_process];
    if (!p || p->magic != 1234)
        return -EBADF;

// file pointer
    fp = (file *) p->Objects[oldfd];
    if (!fp) 
        return -EBADF;
    if (fp->magic != 1234) 
        return -EBADF;

    // Find next free slot >= start
    for (newfd = start; newfd < OPEN_MAX; newfd++) 
    {
        if (p->Objects[newfd] == 0)
        {
            p->Objects[newfd] = (unsigned long) fp;

            return (int) newfd;  // Done
        }
    }

    return (int) -EMFILE;  // no free slots
}

// Pega um fd na lista de arquivos do processo, dado o PID.
// Objects[i]
int fs_get_free_fd_from_pid (pid_t pid)
{
    register int __slot=0;
    struct te_d *p;

// Parameter
    if (pid<0 || pid >= PROCESS_COUNT_MAX){
        debug_print ("fs_get_free_fd_from_pid: pid\n");
        goto fail;
    }

// Process
    p = (struct te_d *) teList[pid];
    if ((void *) p == NULL){
        debug_print ("fs_get_free_fd_from_pid: p\n");
        goto fail;
    }
    if (p->used != TRUE || p->magic != 1234){
        debug_print ("fs_get_free_fd_from_pid: p validation\n");
        goto fail;
    }

// Pick a free one and return the index.
// Each element has a pointer for the file structure?
    for (__slot=0; __slot<32; __slot++)
    {
        if (p->Objects[__slot] == 0){
            return (int) __slot;
        }
    };

fail:
    return (int) -1;
}

// fs_initialize_process_cwd:
// Each process must initialize its data here.
// #todo:
// handle return value ...
// What functions is calling us?

int fs_initialize_process_cwd(pid_t pid, const char *string)
{
    struct te_d *p;
    register int i=0;

// Parameters
    if (pid<0 || pid >= PROCESS_COUNT_MAX){
        debug_print ("fs_initialize_process_cwd: pid\n");
        return 1;
    }
    if ((void *) string == NULL){
        panic ("fs_initialize_process_cwd: string\n");
        //return 1;
    }
    if (*string == 0){
        panic ("fs_initialize_process_cwd: *string\n");
        //return 1;
    }

// Current process.
// #importante
// Vamos copiar a string para a estrutura do processo atual.

    p = (struct te_d *) teList[pid];
    if ((void *) p == NULL){
        panic ("fs_initialize_process_cwd: p\n");
    }
    if ( p->used != 1 || p->magic != 1234 ){
        panic ("fs_initialize_process_cwd: validation\n");
    }

// The buffer has 32 bytes.
// #bugbug: What is the string size?
// It needs to be less than 32.
    //size_t StringSize = (size_t) strlen(string);

    for (i=0; i<32; i++){
        p->cwd_string[i] = 0;
    };
    for (i=0; i<32; i++){
        p->cwd_string[i] = string[i];
    };
    p->cwd_string[31] = 0;  // Finalize 

    return 0;
}

// fs_pathname_backup:
// Remove n directory names from 
// the pathname of the process indicated in the argument.
// Copy the name to the global string.
// Remove the last N directories from PATH.
// Do not leave a blank path.
// PATH must contain enough space for MAXPATHLEN characters.

void fs_pathname_backup(pid_t pid, int n)
{
    struct te_d *p;
    register int i=0;

// CWD
    if (CWD.initialized != TRUE){
        printk ("fs_pathname_backup: CWD not initialized\n"); 
        return;
    } 

// Parameters
    if ( pid<0 || pid >= PROCESS_COUNT_MAX ){
        printk ("fs_pathname_backup: pid\n"); 
        return;
    }
    if (n <= 0) {
        return;
    }

// Process
    p = (struct te_d *) teList[pid];
    if ((void *) p == NULL){
        panic ("fsUpdateWorkingDiretoryString: p\n");
    }
    if ( p->used != TRUE || p->magic != 1234 ){
        panic ("fsUpdateWorkingDiretoryString: validation\n");
    }

    char *path = (char *) p->cwd_string;

    register char *s = path + strlen(path);
 
    if (*path){ 
        s--;
    };

    while (n--)
    {
        while (*s == '/'){ s--; };
        while (*s != '/'){ s--; };

        *++s = '\0';
    };

// Atualizando a string global.
    for ( i=0; i<32; i++ ){
        CWD.path[i] = p->cwd_string[i];
    };

// Name
    for ( i=0; i< 11; i++ ){
        current_target_dir.name[i] = '\0';
    };
}

// Service 170: Print the cwd string of a given PID.
int fs_print_process_cwd(pid_t pid)
{
    struct te_d *p;  // Process structure

    printk("fs_print_process_cwd:\n");

// Parameter
    if (pid<0 || pid>=PROCESS_COUNT_MAX){
        debug_print ("fs_print_process_cwd: pid\n");
        goto fail;
    }

// Process
    p = (struct te_d *) teList[pid];
    if ((void *) p == NULL){
        panic ("fs_print_process_cwd: p\n");
    }else{
        if ( p->used != 1 || p->magic != 1234 ){
            panic ("fs_print_process_cwd: validation\n");
        }

        // #bugbug
        // Is this element a pointer or a buffer ?
        // >>> This element is an array.
        
        // #bugbug: Size of string
        if ((void *) p->cwd_string != NULL)
        {
            //p->cwd_string[31] = 0;
            printk ("> PID=%d p->cwd_string {%s}\n", 
                p->pid, p->cwd_string);
        }

        // #bugbug
        // Is this element a pointer or a buffer ?

        if ( (void *) current_target_dir.name != NULL )
        {
            //current_target_dir.name[31] = 0;
            printk ("> PID=%d current_target_dir.name {%s}\n", 
                p->pid, current_target_dir.name);
        }

        return 0;
    };

fail:
    debug_print ("fs_print_process_cwd: fail\n");   
    return (int) -1;
}

// #todo: showing only few fields
void fs_show_file_info(file *f)
{
//    size_t StringSize=0;

// Parameter
    if ((void*) f == NULL){
        debug_print("fs_show_file_info: fail\n");
        return;
    }
    if (f->used != TRUE)
        return;

    // #bugbug: What is the size?
    // StringSize = (size_t) strlen(f->_tmpfname);
    if ((void*) f->_tmpfname != NULL){
        printk ("Name={%s}\n",f->_tmpfname);
    }

    // ...
}

// Global table
void fs_show_file_table(void)
{
    file *f;
    register int i=0;

    printk ("\nfile_table:\n");
    
    for (i=0; i<32; i++)
    {
        f = (file*) file_table[i];
        if ((void*)f != NULL){
            fs_show_file_info(f);
        }
    };
}

void fs_show_inode_info (struct inode_d *i)
{

// Parameter
    if ((void *) i == NULL){
        debug_print("fs_show_inode_info: fail\n");
        return;
    }
    if (i->used != TRUE)
        return;

    if ((void*)i->path != NULL){
        printk ("Name={%s}\n",i->path);
    }
}

void fs_show_inode_table(void)
{
    struct inode_d *inode;
    register int i=0;

    printk ("inode_table:\n");
    for (i=0; i<32; ++i)
    {
        inode = (struct inode_d *) inode_table[i];
        if ((void *)inode != NULL)
        {
            if ( inode->used == 1 && inode->magic == 1234 )
            {
                fs_show_inode_info(inode);
            }
        }
    };
}

void fs_show_root_fs_info(void)
{
    printk ("fs_show_root_fs_info:\n");

// root fs structure.

    if ((void *) root == NULL){
        printk ("No root structure\n");
        goto fail;
    }
    if (root->used != 1 || root->magic != 1234)
    {
        printk ("Validation fail\n");
        goto fail;
    }

    printk("name = %s\n",       root->name );
    printk("Object type %d\n",  root->kobj._type );
    printk("Object class %d\n", root->kobj._class );
    printk("type = %d\n",       root->type );
    printk("Dir entries %d\n",  root->dir_entries );
    printk("Entry size %d\n",   root->entry_size );
    // ...
    return;  // done

fail:
    printk("fail\n");
}

/*
 * do_read_file_from_disk: 
 *     This is called by sys_open() and sys_read_file_from_disk().
 */
// Usada por open().
// Tem que retornar o fd e colocar o ponteiro na lista de arquivos abertos.
// Carrega um arquivo do disco para a memória.
// #bugbug
// Na minha maquina real, as vezes da problema no tamanho do arquivo.
// #bugbug
// Precisamos colocar os arquivos também na 
// lista global de arquivos abertos. file_table[]
// E na lista de inodes. inode_table[]
// #bugbug
// Nao seria o read() usado para ler um arquivo ja aberto?
// Sim, a rotina de suporte para read esta em sys_read e 
// nao chama esse worker aqui.
// #todo:
// Essa aqui poderia ter outro nome, pois ela carrega um arquivo
// poderia chamar-se loadxxxx().
// See: fs.c
// Limits:
// Probably BUFSIZ (1024 for now) is the limit for this routine.
// To improve this we need to allocate a bigger buffer 
// in the file structure.

// IN:  filename, flags, more
// OUT: file pointer

file *do_read_file_from_disk ( 
    char *file_name, 
    int flags, 
    mode_t mode )
{
    file *fp;  // File pointer (return value)
    size_t FileSize = -1;
    void *buff;
    int __slot = -1;  // fd

    struct te_d *p;  // Process structure

    int __ret = -1;
    int Status = -1;

// #todo:
// Provisory targets.
// For now we're just able to get files and info
// in the root dir.
// Default: Root dir.
    unsigned long TargetDirAddress = VOLUME1_ROOTDIR_ADDRESS;
    unsigned long NumberOfEntries = FAT16_ROOT_ENTRIES;

// Parameters:

    if ((void*) file_name == NULL)
    {
        //return (int) (-EINVAL);
        goto fail;
    }
    if (*file_name == 0)
    {
        //return (int) (-EINVAL);
        goto fail;
    }

// -------------------------------------------
// Root dir?
    if (*file_name == '/')
    {
        TargetDirAddress = VOLUME1_ROOTDIR_ADDRESS;
        NumberOfEntries = FAT16_ROOT_ENTRIES;
        file_name++;
    }

// -------------------------------------------
// Reserved shortcut
    //if (*file_name == '!')
    //{}
// -------------------------------------------

// -------------------------------------------
// Is it inside the GRAMADO/ folder?
// This is not a new root directory for the whole system,
// it is only the directory where we're gonna serch
// for the the desired file.
// Remember: 
// We can setup the memory address for this directory 
// in the structure sdGRAMADO.
    if (*file_name == '@')
    {
        if (sdGRAMADO.initialized != TRUE){
            printk("do_read_file_from_disk: sdGRAMADO.initialized\n");
            goto fail;
        }
        if (sdGRAMADO.address == 0){
            printk("do_read_file_from_disk: sdGRAMADO.address\n");
            goto fail;
        }
        TargetDirAddress = sdGRAMADO.address;
        NumberOfEntries = FAT16_ROOT_ENTRIES;
        file_name++;
        goto EndOfShortcuts;
    }
// -------------------------------------------

// -------------------------------------------
// Is it inside the DE/ folder?
// This is not a new root directory for the whole system,
// it is only the directory where we're gonna serch
// for the the desired file.
// Remember: 
// We can setup the memory address for this directory 
// in the structure sdDE.

    if (*file_name == '#')
    {
        if (sdDE.initialized != TRUE){
            printk("do_read_file_from_disk: sdDE.initialized\n");
            goto fail;
        }
        if (sdDE.address == 0){
            printk("do_read_file_from_disk: sdDE.address\n");
            goto fail;
        }
        TargetDirAddress = sdDE.address;
        NumberOfEntries = FAT16_ROOT_ENTRIES;
        file_name++;
        goto EndOfShortcuts;
    }
// -------------------------------------------

// -------------------------------------------
// Reserved shortcut
    //if (*file_name == '$')
    //{}
// -------------------------------------------

// -------------------------------------------
// Reserved shortcut
    //if (*file_name == '%')
    //{}
// -------------------------------------------

EndOfShortcuts:

// Convertendo o formato do nome do arquivo.    
// >>> "12345678XYZ"
// #todo: 
// Não fazer isso em ring3.

// Add 'BIN' extension if we don't have one.
    //fs_fntos((char *) file_name);
// Add '   ' (3 spaces) extension if we don't have one.
    fs_fntos2((char *) file_name);

// #debug

    //printk ("do_read_file_from_disk: FILE={%s}\n", file_name);

// #bugbug
// We need to search in the inode list. inode_table[]
// If the file is found in the inode list, so we don't
// need to load it again, just increment the counter.

    // #todo
    // fs_search_inode_table(file_name);

// Searching for the file into a given directory.
// #bugbug:
// If we will create a file when it doesn't exist, it means 
// 'cat' command cant call this function, and 
// (This function is a woker for open()).

    Status = (int) search_in_dir(file_name, TargetDirAddress);

// -- Found ----
    if (Status == TRUE){
        goto __go;
    }

// -- Not found ----
// Let's create it if the flags tell us to do that
    if (Status != TRUE)
    {
        //#debug
        printk ("do_read_file_from_disk: [FIXME] File not found\n");

        // Create a new one.
        // #todo: Use sys_create_empty_file.
        if (flags & O_CREAT)
        {
            debug_print ("do_read_file_from_disk: [O_CREAT] Creating a new file\n"); 

            // #todo:
            // Define the default value for this case.
            buff = (void*) kmalloc(BUFSIZ);
            if ((void*) buff == NULL){
                printk("do_read_file_from_disk: buff\n");
                goto fail;
            }
            memset(buff,0,BUFSIZ);
            ksprintf(buff,"This is a new file.");

            //++
            // See: 
            __ret = 
                (int) fat16SaveFile ( 
                          VOLUME1_FAT_ADDRESS, 
                           TargetDirAddress, 
                           NumberOfEntries, 
                           (char *) file_name, 
                           (unsigned long)  1,    // 1, size in sectors 
                           (unsigned long) 512,  // 512, size in bytes  
                           (char *) buff,         // buffer ?
                           (char) 0x20 );         // flag 
              //--

            // Fail
            if (__ret < 0){
                debug_print("do_read_file_from_disk: on fat16SaveFile()\n");
                goto fail;
            }

            // OK
            goto __go;
        }
        // fail
        printk("do_read_file_from_disk: [FIXME] Can't create new file\n");
        goto fail;
    }

__go:

// Get the process pointer
    p = (struct te_d *) get_current_process_pointer();
    if ((void *) p == NULL){
        printk("do_read_file_from_disk: p\n");
        goto fail;
    }
    if (p->used != TRUE || p->magic != 1234){
        printk("do_read_file_from_disk: p validation\n");
        goto fail;
    }
// Find an empty spot in the list of open files
    for (__slot=0; __slot < FOPEN_MAX; __slot++)
    {
        if (p->Objects[__slot] == 0)
        {
            goto __OK;
        }
    };
// Fail
    //panic ("do_read_file_from_disk: No slots!\n");
    printk("do_read_file_from_disk: No slots\n");
    goto fail;

// An empty slot was found in the list of open files
__OK:

    if (__slot < 0 || __slot >= FOPEN_MAX){
        printk ("do_read_file_from_disk: Slot fail\n");
        goto fail;
    }

// Create and initialize file structure
    fp = (file *) kmalloc(sizeof(file));
    if ((void *) fp == NULL){
        printk ("do_read_file_from_disk: fp\n");
        goto fail;
    }
    memset( fp, 0, sizeof(file) );

    // Identifications
    fp->used = TRUE;
    fp->magic = 1234;
    fp->pid = (pid_t) p->pid;
    fp->uid = (uid_t) current_user;
    fp->gid = (gid_t) current_group;

    // File type
    // #bugbug: 
    // Creating a regular file in a worker
    // called by sys_open().
    fp->____object = ObjectTypeFile;

    // #todo:
    // Filename support
    // We need to get the name in the inode.
    //fp->_tmpfname = NULL;

    // Permission
    // #bugbug: Permissions depend on the file type
    fp->sync.can_read = TRUE;
    fp->sync.can_write = TRUE;
    fp->sync.action = ACTION_NULL;

    // File size and buffer size
    fp->_fsize = 0;
    fp->_lbfsize = BUFSIZ;

    // Initialize read and write offsets and counter
    fp->_r = 0;
    fp->_w = 0;
    fp->_cnt = BUFSIZ;  // Anda temos bastante espaço. todo o buffer

    // Number of processes accessing this file?
    fp->fd_counter = 1;

    fp->_file = __slot;  // fd

// #todo
// Se ele não foi encontrado na lista de inodes
// e tivemos que carrega-lo do disco, então
// precisamos colocar ele na lista de inodes.. inode_table[]
// Atenção: O arquivo será carregado logo abaixo.

// #todo
// atualizar a tabela  global de arquivos. file_table[]

//
// buffer
//

// Create a buffer for our file.
// #bugbug: 
// open() is calling this worker here.
// what happens when the file is bigger than this buffer?
// #ps: We are creating a second buffer in this case,
// still limited to 8KB.
// It means the allocation happens twice, wasting memory.

    fp->_base = (char *) kmalloc(BUFSIZ);
    if ((void *) fp->_base == NULL){
        printk ("do_read_file_from_disk: fp->_base\n");
        goto fail;
    }
    memset(fp->_base, 0, BUFSIZ);
    fp->_lbfsize = BUFSIZ;

    // #debug
    //printk ("File name = {%s}\n", file_name);

// File size

    FileSize = 
        (size_t) fsGetFileSize( 
                    (unsigned char *) file_name,
                    (unsigned long) TargetDirAddress );

    if (FileSize <= 0){
        printk ("do_read_file_from_disk: FileSize\n");
        goto fail;
    }
    fp->_fsize = (int) FileSize;

// #test
// The file size is bigger than the buffer size
    if (FileSize >= fp->_lbfsize)
    {
        // #debug
        printk("do_read_file_from_disk: Out of (BUFSIZ) limit\n");
        printk("Creating a larger buffer\n");
        //printk("Size {%d}\n",FileSize);
        //goto fail;

        // #bugbug: Provisório.
        // Limite - 1MB.
        //if (FileSize > 1024*1024)
        if (FileSize > 8*1024)  //8 KB
        {
            printk("do_read_file_from_disk: Out of (8 KB) limit\n");
            printk("%d bytes \n", FileSize);
            goto fail;
        }

        // Allocate new buffer.
        // The buffer must to be bigger than the file size.
        // #bugbug:
        // We need a limit here.
        // The limit is 8KB. See above.

        size_t buflen = FileSize+8;

        fp->_base = (char *) kmalloc(buflen);
        if ((void *) fp->_base == NULL){
            printk ("do_read_file_from_disk: Couldn't create a new buffer\n");
            goto fail;          
        }
        memset(fp->_base, 0, buflen);
        fp->_lbfsize = (int) buflen;  // New file size
    }

// Check base address again
    if ((void *) fp->_base == NULL){
        printk("do_read_file_from_disk: fp->_base again\n");
        goto fail;
    }
    fp->_p = fp->_base;  // Base pointer

// -----------------------------------------
// We have enough space into the buffer
    if (fp->_fsize < fp->_lbfsize)
    {
        fp->_cnt = (fp->_lbfsize - fp->_fsize);
        fp->_r = 0;           // The start. Nothis was read yet.
        fp->_w = fp->_fsize;  // The file size
    }

// -----------------------------------------
// #bugbug: We don't have enough space yet.
// #ps: File size can't be larger than the buffer size.
    if (fp->_fsize >= fp->_lbfsize)
    {
        fp->_cnt = 0;
        fp->_r = fp->_lbfsize;
        fp->_w = fp->_lbfsize;
        // #bugbug: No more space into the buffer
        printk ("do_read_file_from_disk: File larger than buffer\n");
        goto fail;
    }

// Load the file into the memory
    //printk("Load ....\n");

    Status = 
        (int) fat16LoadFile ( 
                VOLUME1_FAT_ADDRESS, 
                TargetDirAddress, 
                NumberOfEntries,
                file_name, 
                (unsigned long) fp->_base,
                fp->_lbfsize );

    if (Status < 0){
        printk("do_read_file_from_disk: on fat16LoadFile()\n");
        goto fail;
    }
    //printk("Loaded ....\n");

//
// Pointer. (mode)
//

// Ajusta o ponteiro para depois do tamanho do arquivo.
// Dependendo do modo.
// See:
// https://linux.die.net/man/2/open

    /*
        O_RDONLY        open for reading only
        O_WRONLY        open for writing only
        O_RDWR          open for reading and writing
        O_NONBLOCK      do not block on open or for data to become available
        O_APPEND        append on each write
        O_CREAT         create file if it does not exist
        O_TRUNC         truncate size to 0
        O_EXCL          error if O_CREAT and the file exists
        O_SHLOCK        atomically obtain a shared lock
        O_EXLOCK        atomically obtain an exclusive lock
        O_NOFOLLOW      do not follow symlinks
        O_SYMLINK       allow open of symlinks
        O_FSYNC         write will save into the disk. :)
    */

// Saving into de disk ?
// You can use the O_FSYNC open mode to make write always 
// store the data to disk before returning;    

     // Default ???

    //if (mode == 0)
    //{
        //debug_print ("do_read_file_from_disk: default mode\n");
        //fp->_p = fp->_base;
    //}

// Offsets: again?
    fp->_cnt = (fp->_lbfsize - fp->_fsize);
    fp->_r = 0;
    fp->_w = fp->_fsize;

//
// mode    #todo
//

// The file is opened in append mode. 
// O offset fica no fim do arquivo.
    if (mode & O_APPEND){
        debug_print ("do_read_file_from_disk: O_APPEND\n");
        //fp->_p = fp->_base + s;
    }
    if (mode & O_ASYNC){
        debug_print ("do_read_file_from_disk: O_ASYNC\n");
    }
    // Enable the close-on-exec flag for the new file descriptor.
    // if ( mode & O_CLOEXEC ){ 
    //     debug_print ("sys_read_file: O_CLOEXEC\n");
    //}
    if (mode & O_CREAT){
        debug_print ("do_read_file_from_disk: O_CREAT\n");
    }

//
// flags
//

// #todo:
// It depends on the mode?

    fp->_flags = (fp->_flags | __SRD);    // ok to read
    //fp->_flags = (fp->_flags | __SWR);  // ok to write

// Save the file pointer into the table of open files
    p->Objects[__slot] = (unsigned long) fp;

    // #debug
    // printk ("process name: %s\n", p->__processname);
    // printk ("fd %d\n", fp->_file);
    // printk("do_read_file_from_disk-OUTPUT: %s \n", fp->_base);
    // ...

    return (file *) fp;  // ok. Valid file pointer

fail:
    return NULL;         // Invalid file pointer
}

/*
 * do_write_file_to_disk:
 *     This is called by sys_write_file_to_disk().
 *     Interface para salvar arquivo ou diretório.
 *     Isso pode ser usado para criar um diretório ou 
 * copiar um diretório. 
 */
// #todo:
// vamos fazer igual ao sys_read_file 
// e criarmos opções ... se possível.
// IN: 
// name, size in sectors, size in bytes, adress, flag.

// Worker
int
do_write_file_to_disk ( 
    char *file_name, 
    unsigned long size_in_sectors,
    unsigned long size_in_bytes,
    char *file_address,
    char flag )  
{
    int __ret = -1;

// #todo:
// We can do the same we did in the Read routine,
// providing a method to access the DE/ GRAMADO/ folders.
    unsigned long TargetDirAddress = VOLUME1_ROOTDIR_ADDRESS;
    unsigned long NumberOfEntries = FAT16_ROOT_ENTRIES;

// Parameter:
    if ((void*) file_name == NULL){
        return (int) (-EINVAL);
    }
    if (*file_name == 0){
        return (int) (-EINVAL);
    }

    // #debug
    // serial_printk ("do_write_file_to_disk: {%s}\n", file_name);

// -------------------------------------------
// Root dir?
    if (*file_name == '/')
    {
        TargetDirAddress = VOLUME1_ROOTDIR_ADDRESS;
        NumberOfEntries = FAT16_ROOT_ENTRIES;
        file_name++;
    }

    // #todo
    // toupper
    // Shortcuts: ! @ # $ %.

//++
// See: write.c
    __ret = 
        (int) fat16SaveFile ( 
                VOLUME1_FAT_ADDRESS, 
                TargetDirAddress, 
                NumberOfEntries,
                (char *) file_name,
                (unsigned long) size_in_sectors,
                (unsigned long) size_in_bytes,
                (char *) file_address,
                (char) flag );
//--

    return (int) __ret;
}

// #todo:
// Change parameter name "file". 
// Maybe we can use "fp" instead.
void set_global_open_file(void *file, int Index)
{

// #todo:
// Limite maximo da lista.

// parameters:
    if ((void *) file == NULL)
    {
        // ?? todo: message
        return;
    }
    if (Index < 0){
        // ?? todo: message
        return;
    }

// Include pointer in the list
    file_table[Index] = (unsigned long) file;
}

// Get a pointer in file_table[i] given the index.
// Get file pointer?
// Can we use "FILE *" instead?
void *get_global_open_file (int Index)
{

//Limits.
//@todo: max. NUMBER_OF_FILES

    if (Index < 0){
        // ?? todo: message
        return NULL;
    }

    return (void *) file_table[Index];
}

// Called by sys_fcntl().
int __sys_fcntl_imp(int fd, int cmd, unsigned long arg)
{
    debug_print ("__sys_fcntl_imp: #todo\n");

// Parameters
    if (fd < 0 || fd >= OPEN_MAX){
        return (int) (-EBADF);
    }
    if (cmd < 0){
        return (int) (-EINVAL);
    }

// File pointer:

    file *fp = get_file_from_fd(fd);
    if (!fp) 
        return -EBADF;
    if (fp->magic != 1234) 
        return -EBADF;


// POSIX Table 6-1.
// See: fcntl.h

    switch (cmd){

    // Duplicating a file descriptor
    // Return: The new file descriptor.
    case F_DUPFD:
        return fs_duplicate_fd(fd, arg);
        break;
    
    // F_DUPFD_CLOEXEC
    // Duplicate FD ≥ arg and set FD_CLOEXEC
    case F_DUPFD_CLOEXEC: 
    {
        int newfd = fs_duplicate_fd(fd, arg);
        if (newfd >= 0)
        {
            file *newfp = get_file_from_fd(newfd);
            if (newfp) 
                newfp->fd_flags |= FD_CLOEXEC;
        }
        return newfd;
    }

    // File descriptor flags

    // Return (as the function result) the file descriptor flags.
    case F_GETFD:
        return fp->fd_flags;
        break;

    // Set the file descriptor flags to the value specified by arg.
    case F_SETFD:
        fp->fd_flags = arg;
        return 0;
        break;

    // File status flags:
    // Return (as the function result) the file access mode and
    // the file status flags; arg is ignored.
    // Return: Value of file status flags.
    case F_GETFL:
        return fp->_flags;
        break;

    // Set the file status flags to the value specified by arg.
    case F_SETFL:
        fp->_flags = arg;
        return 0;
        break;

    // Advisory record locking

    // Get record locking information
    case F_GETLK:
        debug_print ("__sys_fcntl_imp: [TODO] F_GETLK\n");
        goto fail;
        break;

    // Set record locking information
    case F_SETLK:
        debug_print ("__sys_fcntl_imp: [TODO] F_SETLK\n");
        goto fail;
        break;

    // Set record locking info; wait if blocked
    case F_SETLKW:
        debug_print ("__sys_fcntl_imp: [TODO] F_SETLKW\n");
        goto fail;
        break;

    // Free a section of a regular file
    case F_FREESP:
        // truncate logic: free space starting at arg
        fp->_fsize = (int) arg;
        return 0;
        break;

    // ...

    // Invalid or not supported command value.
    default:
        return (int) (-EINVAL);
        break;
    };

fail:
    debug_print ("sys_fcntl: FAIL\n");
    return (int) -1;
}


// Clear the list 'dev_dir[i]'.
int fs_initialize_dev_dir(void)
{
    register int i=0;
    static int NumberOfSlots = 32;

    for (i=0; i<NumberOfSlots; i++)
    {
        dev_dir[i].used = FALSE;
        dev_dir[i].magic = FALSE;
        dev_dir[i].initialized = FALSE;
        dev_dir[i].path[0] = 0;
        dev_dir[i].fp = NULL;
    };

    return 0;
}

// Update the 'Current Working Directory' string.
// string:>
void fsInitializeWorkingDiretoryString (void)
{

    // #bugbug
    // We have some issues with string sizes.
    // Buffer overflow!

    // vamos contar o tamanho da string que estamos construindo.
    int string_count = 0;
    int string_size = 0;
    struct volume_d  *v;
    char volume_string[8];   

    //debug_print ("fsInitializeWorkingDiretoryString:\n");

// See: 
// fs.h

    CWD.initialized = FALSE;

// volume string 

    volume_string[0] = 'v';
    volume_string[1] = 'o';
    volume_string[2] = 'l';
    volume_string[3] = 'u';
    volume_string[4] = 'm';
    volume_string[5] = 'e';
    volume_string[6] = (char)( '1' + (char) current_volume - (char) 1 );
    volume_string[7] = '\0';

// 'root:'
//  ## volume list ##
// Primeiro colocamos a string que indica a lista de volumes. 
    ksprintf(CWD.path,FS_ROOT_STRING); 

// '/'
// ## separador ##
    strcat(CWD.path,FS_PATHNAME_SEPARATOR);

//
// volume root dir 
//

// #todo: Check overflow.
    if (current_volume < 0){
        panic ("fsInitializeWorkingDiretoryString: current_volume\n");
    }
    //if (current_volume >= ?)
        //something()

// Structure pointer
    v = (struct volume_d *) volumeList[current_volume];
    if ((void *) v == NULL){
        panic ("fsInitializeWorkingDiretoryString: v\n");
    }else{
        if ( v->used != TRUE || v->magic != 1234 ){
            panic ("fsInitializeWorkingDiretoryString: validation\n");
        }

        switch (v->id)
        {
			//case 0:
		        //global usada para string do nome do volume.
			//    current_volume_string = (char *) FS_VOLUME0_STRING;
			//    break;

			//case 1:
		        //global usada para string do nome do volume.
			//   current_volume_string = (char *) FS_VOLUME1_STRING;
			//   break;
			
            default:
		        //fail.
		        //printk("fsInitializeWorkingDiretoryString: default volume #todo\n");
		        //die();
                current_volume_string = (char *) volume_string; 
                break;
        };

        // #bugbug
        // We need to finalize the string.
        // limit 32.
        // See: volume.h
        
        // path string na estrutura do volume.
        
        string_size = sizeof(current_volume_string);
        if (string_size >= 32){
            debug_print ("fsInitializeWorkingDiretoryString: [FIXME] string size\n"); 
            return;
        }
        
        // copy the string. limit 32 bytes.
        ksprintf ( v->path_string, current_volume_string );
        
        // finalize.
        v->path_string[31] = 0;

        // #bugbug
        // What is the limit for this string ? 32 bytes.
        // See: rtl/fs/path.h and globals.h

        strcat ( CWD.path, v->path_string );
	    //strcat ( CWD.path, current_volume_string );
	    
        CWD.path[31] = 0;
    };

// #bugbug
// What is the limit for this string ? 32 bytes.
// See: path.h and globals.h

// Separador
    strcat ( CWD.path, FS_PATHNAME_SEPARATOR );
    CWD.path[31] = 0;

// Size
    size_t PathSize=0;
    PathSize = (size_t) strlen(CWD.path);
    if (PathSize > 31){
        PathSize = 31;
    }
    CWD.size = PathSize;

// More ?...

    //debug_print ("fsInitializeWorkingDiretoryString: done\n");

// See: fs.h
    CWD.initialized = TRUE;
}


// =========================================
// __fs_initialize_imp:
// Called by fsInitialize() in fs.c.

int __fs_initialize_imp(void)
{
//    register int i=0;
    int slot = -1;

// Initialize slab buffers to load directories.
    int buffers_ok = (int) __initialize_fs_buffers();
    if (buffers_ok < 0){
        panic("__fs_initialize_imp: buffers");
    }

// Undefined fs type.
    set_filesystem_type(FS_TYPE_NULL);

// Initialize fat16 support for the system's volume.
// #todo: 
// Devemos checar o tipo da partiçao de boot. 
// Se nao aqui, depois!
    fat16Init();

// Init dev/ dir.
// Is it a 'virtual folder'?
    printk("__fs_initialize_imp: fs_initialize_dev_dir\n");
    fs_initialize_dev_dir();

//
// == fileList =========================
//

// Initializing the file pointers
// volume1_rootdir_fp and volume2_rootdir_fp.
// See: kstdio.h

//
// == volume1_rootdir ================================
//

    // pega slot em file_table[] para
    slot = get_free_slots_in_the_file_table();
    if (slot<0 || slot >= NUMBER_OF_FILES){
        panic("__fs_initialize_imp: slot\n");
    }
    volume1_rootdir_fp = (file *) file_table[slot];
    volume1_rootdir_fp->filetable_index = slot;

    if ((void *) volume1_rootdir_fp == NULL){
        panic ("__fs_initialize_imp: volume1_rootdir_fp\n");
    }

    volume1_rootdir_fp->used = TRUE;
    volume1_rootdir_fp->magic = 1234;
    volume1_rootdir_fp->____object = ObjectTypeVolume;

    volume1_rootdir_fp->_base = (unsigned char *) VOLUME1_ROOTDIR_ADDRESS;
    volume1_rootdir_fp->_p    = (unsigned char *) VOLUME1_ROOTDIR_ADDRESS;
    volume1_rootdir_fp->_cnt = (32 * 512);
    volume1_rootdir_fp->_file = 0;
    volume1_rootdir_fp->_tmpfname = "VOLUME1 VOL";
    volume1_rootdir_fp->fd_counter = 1;

// #bugbug: 
// Validade da estrutura.
        
// ...
// inode support.
// pega slot em inode_table[] 
    slot = get_free_slots_in_the_inode_table();
    if (slot < 0 || slot >= 32){
        panic("__fs_initialize_imp: volume1_rootdir_fp inode slot\n");
    }
    volume1_rootdir_fp->inode = (struct inode_d *) inode_table[slot];
    volume1_rootdir_fp->inodetable_index = slot;
    if ((void*) volume1_rootdir_fp->inode == NULL){
        panic("__fs_initialize_imp: volume1_rootdir_fp inode struct\n");
    }
    volume1_rootdir_fp->inode->filestruct_counter = 1;  //inicialize
    memcpy ( 
        (void*)       volume1_rootdir_fp->inode->path, 
        (const void*) volume1_rootdir_fp->_tmpfname, 
              sizeof( volume1_rootdir_fp->inode->path ) );
    // ... 

// #test
// The file pointer represents the boot volume.
// see: storage.h
    if ((void*) storage == NULL)
        panic("__fs_initialize_imp: storage\n");
    if (storage->magic != 1234)
        panic("__fs_initialize_imp: storage validation\n");

    storage->bootvolume_fp = (file *) volume1_rootdir_fp;

//
// == volume2_rootdir =========================================== 
//
    // pega slot em file_table[] para
    slot = get_free_slots_in_the_file_table();
    if (slot<0 || slot >= NUMBER_OF_FILES){
        panic("__fs_initialize_imp: slot\n");
    }
    volume2_rootdir_fp = (file *) file_table[slot];
    volume2_rootdir_fp->filetable_index = slot;

    if ((void *) volume2_rootdir_fp == NULL){
        panic ("__fs_initialize_imp: volume2_rootdir_fp\n");
    }
    volume2_rootdir_fp->used = TRUE;
    volume2_rootdir_fp->magic = 1234;
    volume2_rootdir_fp->____object = ObjectTypeVolume;
 
    volume2_rootdir_fp->_base = (unsigned char *) VOLUME2_ROOTDIR_ADDRESS;
    volume2_rootdir_fp->_p    = (unsigned char *) VOLUME2_ROOTDIR_ADDRESS;
    volume2_rootdir_fp->_cnt = (32 * 512);  // #bugbug: Check this size.
    volume2_rootdir_fp->_file = 0;          // ?
    volume2_rootdir_fp->_tmpfname = "VOLUME2 VOL";
    volume2_rootdir_fp->fd_counter = 1;

// ...
// inode support.
// pega slot em inode_table[] 
    slot = get_free_slots_in_the_inode_table();
    if (slot<0 || slot >= 32){
        panic("__fs_initialize_imp: volume2_rootdir inode slot\n");
    }
    volume2_rootdir_fp->inode = (struct inode_d *) inode_table[slot];
    volume2_rootdir_fp->inodetable_index = slot;
    if ( (void*) volume2_rootdir_fp->inode == NULL ){
        panic("__fs_initialize_imp: volume2_rootdir_fp inode struct");
    }
    volume2_rootdir_fp->inode->filestruct_counter = 1;  //inicialize
    memcpy ( 
        (void*)       volume2_rootdir_fp->inode->path, 
        (const void*) volume2_rootdir_fp->_tmpfname, 
              sizeof( volume2_rootdir_fp->inode->path ) );
        // ... 

//
// == pipe_gramadocore_init_execve ================================ 
//

// ## Inicializando os pipes usados em execve ## 
// gramado core init execve 
// #todo: mudar para pipe_gramadocore_init_execve_fp
// aloca memoria para a estrutura.
    
    pipe_gramadocore_init_execve = (file *) kmalloc(sizeof(file));
    if ((void *) pipe_gramadocore_init_execve == NULL){
        panic ("__fs_initialize_imp: pipe_gramadocore_init_execve\n");
    }

// Aloca memória para o buffer.
// #todo: Define this variable in the top of the body.
// #bugbug: Chech this size.
// #todo: Use BUFSIZ as a normal file.
    unsigned long pipe0base = (unsigned long) kmalloc(512);
    if ((void *) pipe0base == NULL){
        panic ("__fs_initialize_imp: pipe0base\n");
    }

    pipe_gramadocore_init_execve->used = TRUE;
    pipe_gramadocore_init_execve->magic = 1234;

    pipe_gramadocore_init_execve->_base = (unsigned char *) pipe0base;
    pipe_gramadocore_init_execve->_p    = (unsigned char *) pipe0base;
    pipe_gramadocore_init_execve->_cnt  = 512;  // #bugbug: Check this size.
    pipe_gramadocore_init_execve->_file = 0;    // ??
    pipe_gramadocore_init_execve->_tmpfname = "pipe0";

    // #todo
    //fileList[ ? ] = (unsigned long) pipe_gramadocore_init_execve;

    // 0
    pipeList[0] = (unsigned long) pipe_gramadocore_init_execve;

// -------------------------

    // #deprecated
    //init_directory_facilities();

// CWD Structure.
// Inicializa o pwd support.
    fsInitializeWorkingDiretoryString();

// Target dir struct
// Inicializa a estrutura de suporte ao target dir.
    printk("__fs_initialize_imp: fsInitTargetDir\n");
    fsInitTargetDir(VOLUME1_ROOTDIR_ADDRESS,"/");

// FAT support for the boot partition
    printk("__fs_initialize_imp: fsbp_initialize_fat\n");
    fsbp_initialize_fat();

// Initialize boot partitions canonical directories.
// see: fsbp.c
    printk("__fs_initialize_imp: fsbp_initialize_bp_directories\n");
    fsbp_initialize_bp_directories();
    // ...

    return 0;  // OK

fail:
    return (int) -1;
}

//
// End
//
