// fat.h
// Main structures and function prototypes used 
// by the FAT filesystem.
// Created by Fred Nora

#ifndef  __FAT_FAT_H
#define  __FAT_FAT_H    1

/*
FAT12/FAT16:
The root directory is located in a fixed position right after the FAT, 
with a maximum size defined in the BPB.

FAT32:
The root directory is treated as a normal directory, located by 
the 'Root Cluster' field in the BPB, and can grow dynamically.
*/


// fat16 structure
struct fat_d
{
    int used;
    int magic;
    int initialized;
    int type;

    unsigned long fat_address;    // Address for FAT  

    unsigned long fat_first_lba;  // First LBA
    unsigned long fat_last_lba;   // last LBA

// FAT sizes:
    unsigned long fat_size_in_sectors;  // Size in sectors
    unsigned long size_in_bytes;        // Size in bytes
    unsigned long size_in_kb;           // Size in KB

    //...
    
    struct volume_d *volume;
};
// See: 
// fs_init_fat in fs.c
// A FAT usada no boot volume.
// see: fat16.c
extern struct fat_d  *bootvolume_fat;


// fat info for the boot partition of the system disk.
struct system_fat_d
{
    int initialized;
    //#todo
    //struct fat_d  *_fat;
    // ...
};



extern struct fat16_directory_entry_d *vol_label_directory_entry;

// 
// == prototypes ==========================================
//


void test_fat16_find_volume_info(void);

int 
fat16_get_entry_info(
    struct fat16_directory_entry_d *entry,
    unsigned long directory_va,
    int entry_number,
    int entry_max );

void from_FAT_name(char *src, char *dst);
void to_FAT_name(char *src, char *dst);

void fs_fat16_cache_not_saved(void);
int fs_save_fat16_cache(void);

unsigned long 
fsGetFileSize ( 
    unsigned char *file_name, 
    unsigned long dir_address );

void 
fsFAT16ListFiles ( 
    const char     *dir_name, 
    unsigned short *dir_va, 
    int            number_of_entries );

void fat16_init_fat_structure(void);
int fat16Init(void);

#endif    
