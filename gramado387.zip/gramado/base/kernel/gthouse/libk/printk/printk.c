// printk.c
// printk support.
// Created by Fred Nora.

#include <kernel.h>

/*
 * printk_old:
 *     @field 2
 *     The printk function.
 *     Assuming sizeof(void *) == sizeof(int).
 * Em user mode temos uma modelo mais tradicional de printk,
 * talvez seja bom implementa-lo aqui tambem.
 */
// #bugbug
// #todo:
// Devemos tentar usar o mesmo printk implementado na libc
// Essa aqui não está no padrão.
// #todo:
// Vamos substtuir essa função por uma de licensa bsd.
// Olhar na biblioteca.
// #suspensa
// Essa implementação foi feita para 32bit e não funciona
// por inteiro em long mode.
// Usaremos kinguio_printf por enquanto.

int printk_old(const char *format, ...)
{
    register int *varg = (int *) (&format);

// #bugbug:
// Se print() está usando '0' como buffer,
// então ele está sujando a IVT?
// #:
// print() nao analisa flags.

    return (int) print(0,varg);
}


// The ring 0 implementation of printf().
// printk is an alias for this function.
// Credits: 
// Nelson Cole. 
// Project Sirius/Kinguio. (BSD license)
// IN:
// fmp - format string. (src)
int kinguio_printf(const char *fmt, ...)
{
    // Destination buffer
    static char dst_buffer[1024];
    int ret=0;

// If the virtual console isn't full initialized yet
    if (Initialization.is_console_log_initialized != TRUE){
        return (int) -1;
    }

    memset (dst_buffer, 0, 1024);

    /*
    if ((void*) fmt == NULL){
        return (int) -1;
    }
    if (*fmt == 0){
        return (int) -1;
    }
    */

//----------
// See: kstdio.c
    va_list ap;
    va_start(ap, fmt);
    ret = (int) kinguio_vsprintf(dst_buffer, fmt, ap);
    va_end(ap);
//-----------

// Now we already have the formated string. Lets:
// + print it or 
// + send it to the serial port.

    size_t BufferSize = (size_t) sizeof(dst_buffer);

//
// Console session type
//

    int SessionType = console_get_session_type(fg_console);

    switch (SessionType)
    {
        case TTY_SESSION_TYPE_CONSOLE:
            kinguio_puts(dst_buffer);
            return 0;  // #bugbug: We need the number of bytes
            break;

        case TTY_SESSION_TYPE_GUI:
            return (int) debug_print_nbytes( 
                    (const void *) dst_buffer, 
                    (size_t) BufferSize );
            break;

        // #todo: This is a work in progress
        case TTY_SESSION_TYPE_REMOTE:
            return (int) debug_print_nbytes( 
                    (const void *) dst_buffer, 
                    (size_t) BufferSize );
            break;

        // #todo: This is a work in progress
        case TTY_SESSION_TYPE_DEBUG:
            return (int) debug_print_nbytes( 
                    (const void *) dst_buffer, 
                    (size_t) BufferSize );
            break;

        // #todo: This is a work in progress
        case TTY_SESSION_TYPE_HEADLESS:
            return (int) debug_print_nbytes( 
                    (const void *) dst_buffer, 
                    (size_t) BufferSize );
            break;

        default:
            return (int) -1;
            break;
    };    

    return (int) ret;
}
// ===================================

// Allocate memory aligned to 'align' boundary.
// align must be a power of two (e.g. 512, 4096).
void *kmalloc_aligned(size_t size, size_t align)
{
    // Allocate extra space so we can align manually
    void *raw = kmalloc(size + align);
    if (!raw) return NULL;

    // Round up to nearest alignment boundary
    unsigned long addr = (unsigned long)raw;
    unsigned long aligned = (addr + (align - 1)) & ~(align - 1);

    // Zero out the aligned region
    memset((void*)aligned, 0, size);

    return (void*)aligned;
}
